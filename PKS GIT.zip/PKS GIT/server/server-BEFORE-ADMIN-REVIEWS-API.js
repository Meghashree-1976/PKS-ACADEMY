﻿require("dotenv").config();

const express = require("express");
const path = require("path");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");

const Inquiry = require("../database/models/Inquiry");
const Admin = require("../database/models/Admin");
const Student = require("../database/models/Student");
const Attendance = require("../database/models/Attendance");
const AcademySettings = require("../database/models/AcademySettings");
const Review = require("../database/models/Review");

const app = express();

const PORT =
    Number(process.env.PORT) || 5000;

const ROOT =
    path.join(__dirname, "..");


/* =========================================================
   ATTENDANCE LOCATION SETTINGS
========================================================= */

// Fixed PKS Computer Education academy location.
// Attendance uses these coordinates regardless of the administrator's browser/device location or any previously saved database value.
const FIXED_ACADEMY_LAT = 14.216399;
const FIXED_ACADEMY_LNG = 76.408972;
const FIXED_ATTENDANCE_RADIUS_METERS = 100;

const ACADEMY_LAT =
    FIXED_ACADEMY_LAT;

const ACADEMY_LNG =
    FIXED_ACADEMY_LNG;

const ATTENDANCE_RADIUS_METERS =
    FIXED_ATTENDANCE_RADIUS_METERS;

const TIME_ZONE =
    process.env.TIME_ZONE || "Asia/Kolkata";


/* =========================================================
   ENVIRONMENT CHECK
========================================================= */

if (!process.env.MONGODB_URI) {

    console.error(
        "❌ MONGODB_URI is missing from .env"
    );

    process.exit(1);
}

if (!process.env.JWT_SECRET) {

    console.error(
        "❌ JWT_SECRET is missing from .env"
    );

    process.exit(1);
}

if (process.env.JWT_SECRET.length < 32) {

    console.error(
        "❌ JWT_SECRET must be at least 32 characters."
    );

    process.exit(1);
}


/* =========================================================
   SECURITY
========================================================= */

app.disable("x-powered-by");

app.use(
    helmet({
        crossOriginResourcePolicy: {
            policy: "cross-origin"
        }
    })
);


/* =========================================================
   BODY PARSING
========================================================= */

app.use(
    express.json({
        limit: "100kb"
    })
);

app.use(
    express.urlencoded({
        extended: true,
        limit: "100kb"
    })
);


/* =========================================================
   STATIC FILES
========================================================= */

app.use(
    express.static(
        path.join(
            ROOT,
            "public"
        )
    )
);

app.use(
    "/admin",
    express.static(
        path.join(
            ROOT,
            "admin"
        )
    )
);

app.use(
    "/student",
    express.static(
        path.join(
            ROOT,
            "student"
        )
    )
);


/* =========================================================
   RATE LIMITING
========================================================= */

const loginLimiter =
    rateLimit({

        windowMs:
            15 * 60 * 1000,

        max:
            10,

        standardHeaders:
            true,

        legacyHeaders:
            false,

        message: {

            success:
                false,

            message:
                "Too many login attempts. Please try again later."

        }

    });


const studentLoginLimiter =
    rateLimit({

        windowMs:
            15 * 60 * 1000,

        max:
            15,

        standardHeaders:
            true,

        legacyHeaders:
            false,

        message: {

            success:
                false,

            message:
                "Too many student login attempts. Please try again later."

        }

    });


const inquiryLimiter =
    rateLimit({

        windowMs:
            15 * 60 * 1000,

        max:
            20,

        standardHeaders:
            true,

        legacyHeaders:
            false,

        message: {

            success:
                false,

            message:
                "Too many inquiries. Please try again later."

        }

    });


const attendanceLimiter =
    rateLimit({

        windowMs:
            15 * 60 * 1000,

        max:
            20,

        standardHeaders:
            true,

        legacyHeaders:
            false,

        message: {

            success:
                false,

            message:
                "Too many attendance attempts. Please try again later."

        }

    });


/* =========================================================
   ADMIN AUTHENTICATION
========================================================= */

function authenticateAdmin(
    req,
    res,
    next
) {

    try {

        const header =
            req.headers.authorization;

        if (
            !header ||
            !header.startsWith("Bearer ")
        ) {

            return res.status(401).json({

                success:
                    false,

                message:
                    "Administrator authentication required."

            });

        }


        const token =
            header.substring(7);


        const decoded =
            jwt.verify(
                token,
                process.env.JWT_SECRET,
                {
                    issuer:
                        "pks-foundation"
                }
            );


        if (
            !decoded ||
            decoded.type !== "admin" ||
            !decoded.adminId
        ) {

            return res.status(401).json({

                success:
                    false,

                message:
                    "Invalid administrator authentication token."

            });

        }


        req.admin =
            decoded;


        next();


    } catch (error) {

        if (
            error.name ===
            "TokenExpiredError"
        ) {

            return res.status(401).json({

                success:
                    false,

                message:
                    "Administrator session expired. Please log in again."

            });

        }


        return res.status(401).json({

            success:
                false,

            message:
                "Invalid administrator authentication token."

        });

    }

}


/* =========================================================
   STUDENT AUTHENTICATION
========================================================= */

function authenticateStudent(
    req,
    res,
    next
) {

    try {

        const header =
            req.headers.authorization;


        if (
            !header ||
            !header.startsWith("Bearer ")
        ) {

            return res.status(401).json({

                success:
                    false,

                message:
                    "Student authentication required."

            });

        }


        const token =
            header.substring(7);


        const decoded =
            jwt.verify(
                token,
                process.env.JWT_SECRET,
                {
                    issuer:
                        "pks-foundation"
                }
            );


        if (
            !decoded ||
            decoded.type !== "student" ||
            !decoded.studentId
        ) {

            return res.status(401).json({

                success:
                    false,

                message:
                    "Invalid student authentication token."

            });

        }


        req.student =
            decoded;


        next();


    } catch (error) {

        if (
            error.name ===
            "TokenExpiredError"
        ) {

            return res.status(401).json({

                success:
                    false,

                message:
                    "Student session expired. Please log in again."

            });

        }


        return res.status(401).json({

            success:
                false,

            message:
                "Invalid student authentication token."

        });

    }

}


/* =========================================================
   HELPER FUNCTIONS
========================================================= */

function getLocalDateString(
    date = new Date()
) {

    const formatter =
        new Intl.DateTimeFormat(
            "en-CA",
            {
                timeZone:
                    TIME_ZONE,

                year:
                    "numeric",

                month:
                    "2-digit",

                day:
                    "2-digit"
            }
        );


    return formatter.format(
        date
    );

}


function isValidCoordinate(
    value
) {

    return Number.isFinite(
        Number(value)
    );

}


function calculateDistanceMeters(
    lat1,
    lng1,
    lat2,
    lng2
) {

    const earthRadius =
        6371000;


    const toRadians =
        degrees =>
            degrees *
            Math.PI /
            180;


    const dLat =
        toRadians(
            lat2 - lat1
        );


    const dLng =
        toRadians(
            lng2 - lng1
        );


    const a =
        Math.sin(dLat / 2) ** 2 +

        Math.cos(
            toRadians(lat1)
        ) *

        Math.cos(
            toRadians(lat2)
        ) *

        Math.sin(
            dLng / 2
        ) ** 2;


    const c =
        2 *

        Math.atan2(
            Math.sqrt(a),
            Math.sqrt(1 - a)
        );


    return (
        earthRadius *
        c
    );

}


function safeStudent(
    student
) {

    const data =
        student.toObject
            ? student.toObject()
            : {
                ...student
            };


    delete data.pinHash;


    return data;

}


/* =========================================================
   ACADEMY LOCATION HELPER
========================================================= */

async function getAcademyLocation() {

    return {

        latitude:
            FIXED_ACADEMY_LAT,

        longitude:
            FIXED_ACADEMY_LNG,

        radiusMeters:
            FIXED_ATTENDANCE_RADIUS_METERS,

        academyName:
            "PKS Computer Education",

        source:
            "code",

        updatedAt:
            null

    };

}


/* =========================================================
   HEALTH CHECK
========================================================= */

app.get(
    "/api/health",
    (req, res) => {

        res.json({

            success:
                true,

            message:
                "PKS Foundation server is running.",

            database:
                mongoose.connection
                    .readyState === 1
                    ? "connected"
                    : "disconnected",

            timestamp:
                new Date().toISOString()

        });

    }
);


/* =========================================================
   ADMIN LOGIN
========================================================= */

app.post(
    "/api/admin/login",
    loginLimiter,

    async (req, res) => {

        try {

            const username =
                typeof req.body.username ===
                "string"

                    ? req.body.username
                        .trim()
                        .toLowerCase()

                    : "";


            const password =
                typeof req.body.password ===
                "string"

                    ? req.body.password

                    : "";


            if (
                !username ||
                !password
            ) {

                return res.status(400).json({

                    success:
                        false,

                    message:
                        "Username and password are required."

                });

            }


            const admin =
                await Admin.findOne({

                    username,

                    isActive:
                        true

                });


            if (!admin) {

                return res.status(401).json({

                    success:
                        false,

                    message:
                        "Invalid username or password."

                });

            }


            const validPassword =
                await bcrypt.compare(
                    password,
                    admin.passwordHash
                );


            if (!validPassword) {

                return res.status(401).json({

                    success:
                        false,

                    message:
                        "Invalid username or password."

                });

            }


            const token =
                jwt.sign(

                    {

                        adminId:
                            admin._id.toString(),

                        username:
                            admin.username,

                        role:
                            admin.role,

                        type:
                            "admin"

                    },

                    process.env.JWT_SECRET,

                    {

                        expiresIn:
                            "8h",

                        issuer:
                            "pks-foundation"

                    }

                );


            return res.json({

                success:
                    true,

                message:
                    "Login successful.",

                token,

                expiresIn:
                    28800,

                admin: {

                    id:
                        admin._id,

                    username:
                        admin.username,

                    name:
                        admin.name,

                    role:
                        admin.role

                }

            });


        } catch (error) {

            console.error(
                "Admin login error:",
                error.message
            );


            return res.status(500).json({

                success:
                    false,

                message:
                    "Unable to process login."

            });

        }

    }
);


/* =========================================================
   ADMIN SESSION
========================================================= */

app.get(
    "/api/admin/me",
    authenticateAdmin,

    async (req, res) => {

        try {

            const admin =
                await Admin.findById(
                    req.admin.adminId
                )
                .select(
                    "_id username name role isActive"
                );


            if (
                !admin ||
                !admin.isActive
            ) {

                return res.status(401).json({

                    success:
                        false,

                    message:
                        "Administrator account is inactive."

                });

            }


            return res.json({

                success:
                    true,

                admin: {

                    id:
                        admin._id,

                    username:
                        admin.username,

                    name:
                        admin.name,

                    role:
                        admin.role

                }

            });


        } catch (error) {

            console.error(
                "Admin session error:",
                error.message
            );


            return res.status(500).json({

                success:
                    false,

                message:
                    "Unable to verify session."

            });

        }

    }
);


/* =========================================================
   ADMIN DASHBOARD
========================================================= */

app.get(
    "/api/admin/dashboard",
    authenticateAdmin,

    async (req, res) => {

        try {

            const date =
                getLocalDateString();


            const totalStudents =
                await Student.countDocuments({

                    isActive:
                        true

                });


            const presentToday =
                await Attendance.countDocuments({

                    date,

                    status: {

                        $in: [

                            "present",

                            "late"

                        ]

                    }

                });


            const absentToday =
                Math.max(

                    totalStudents -
                    presentToday,

                    0

                );


            const newInquiries =
                await Inquiry.countDocuments({

                    status:
                        "new"

                });


            return res.json({

                success:
                    true,

                data: {

                    totalStudents,

                    presentToday,

                    absentToday,

                    newInquiries,

                    date

                }

            });


        } catch (error) {

            console.error(
                "Dashboard error:",
                error.message
            );


            return res.status(500).json({

                success:
                    false,

                message:
                    "Unable to load dashboard."

            });

        }

    }
);


/* =========================================================
   ADMIN STUDENTS - GET ALL
========================================================= */

app.get(
    "/api/admin/students",
    authenticateAdmin,

    async (req, res) => {

        try {

            const students =
                await Student.find()
                    .select("-pinHash")
                    .sort({
                        createdAt:
                            -1
                    });


            return res.json({

                success:
                    true,

                students

            });


        } catch (error) {

            console.error(
                "Get students error:",
                error.message
            );


            return res.status(500).json({

                success:
                    false,

                message:
                    "Unable to load students."

            });

        }

    }
);


/* =========================================================
   ADMIN STUDENTS - CREATE
========================================================= */

app.post(
    "/api/admin/students",
    authenticateAdmin,

    async (req, res) => {

        try {

            const studentCode =
                typeof req.body.studentCode ===
                "string"

                    ? req.body.studentCode
                        .trim()
                        .toUpperCase()

                    : "";


            const name =
                typeof req.body.name ===
                "string"

                    ? req.body.name.trim()

                    : "";


            const pin =
                typeof req.body.pin ===
                "string"

                    ? req.body.pin.trim()

                    : "";


            const fatherName =
                typeof req.body.fatherName ===
                "string"

                    ? req.body.fatherName.trim()

                    : "";


            const fatherPhone =
                typeof req.body.fatherPhone ===
                "string"

                    ? req.body.fatherPhone.trim()

                    : "";


            const motherName =
                typeof req.body.motherName ===
                "string"

                    ? req.body.motherName.trim()

                    : "";


            const motherPhone =
                typeof req.body.motherPhone ===
                "string"

                    ? req.body.motherPhone.trim()

                    : "";


            const studentPhone =
                typeof req.body.studentPhone ===
                "string"

                    ? req.body.studentPhone.trim()

                    : "";


            const address =
                typeof req.body.address ===
                "string"

                    ? req.body.address.trim()

                    : "";


            const course =
                typeof req.body.course ===
                "string"

                    ? req.body.course.trim()

                    : "";


            if (
                !studentCode ||
                !name ||
                !pin
            ) {

                return res.status(400).json({

                    success:
                        false,

                    message:
                        "Student code, name and PIN are required."

                });

            }


            if (
                pin.length < 4 ||
                pin.length > 20
            ) {

                return res.status(400).json({

                    success:
                        false,

                    message:
                        "PIN must be between 4 and 20 characters."

                });

            }


            const existing =
                await Student.findOne({

                    studentCode

                });


            if (existing) {

                return res.status(409).json({

                    success:
                        false,

                    message:
                        "A student with this code already exists."

                });

            }


            const pinHash =
                await bcrypt.hash(
                    pin,
                    12
                );


            const student =
                await Student.create({

                    studentCode,

                    name,

                    pinHash,

                    fatherName,

                    fatherPhone,

                    motherName,

                    motherPhone,

                    studentPhone,

                    address,

                    course,

                    isActive:
                        true

                });


            return res.status(201).json({

                success:
                    true,

                message:
                    "Student created successfully.",

                student:
                    safeStudent(
                        student
                    )

            });


        } catch (error) {

            console.error(
                "Create student error:",
                error.message
            );


            if (
                error.code ===
                11000
            ) {

                return res.status(409).json({

                    success:
                        false,

                    message:
                        "Student code already exists."

                });

            }


            return res.status(500).json({

                success:
                    false,

                message:
                    "Unable to create student."

            });

        }

    }
);


/* =========================================================
   ADMIN STUDENTS - UPDATE
========================================================= */

app.patch(
    "/api/admin/students/:id",
    authenticateAdmin,

    async (req, res) => {

        try {

            const updates = {};


            const fields = [

                "name",

                "fatherName",

                "fatherPhone",

                "motherName",

                "motherPhone",

                "studentPhone",

                "address",

                "course"

            ];


            for (
                const field of fields
            ) {

                if (
                    req.body[field] !==
                    undefined
                ) {

                    updates[field] =
                        typeof req.body[field] ===
                        "string"

                            ? req.body[field].trim()

                            : req.body[field];

                }

            }


            if (
                req.body.studentCode !==
                undefined
            ) {

                const studentCode =
                    typeof req.body.studentCode ===
                    "string"

                        ? req.body.studentCode
                            .trim()
                            .toUpperCase()

                        : "";


                if (studentCode) {

                    updates.studentCode =
                        studentCode;

                }

            }


            if (
                req.body.pin !==
                undefined
            ) {

                const pin =
                    typeof req.body.pin ===
                    "string"

                        ? req.body.pin.trim()

                        : "";


                if (pin) {

                    updates.pinHash =
                        await bcrypt.hash(
                            pin,
                            12
                        );

                }

            }


            const student =
                await Student.findByIdAndUpdate(

                    req.params.id,

                    updates,

                    {

                        new:
                            true,

                        runValidators:
                            true

                    }

                ).select(
                    "-pinHash"
                );


            if (!student) {

                return res.status(404).json({

                    success:
                        false,

                    message:
                        "Student not found."

                });

            }


            return res.json({

                success:
                    true,

                message:
                    "Student updated successfully.",

                student

            });


        } catch (error) {

            console.error(
                "Update student error:",
                error.message
            );


            if (
                error.code ===
                11000
            ) {

                return res.status(409).json({

                    success:
                        false,

                    message:
                        "Student code already exists."

                });

            }


            return res.status(500).json({

                success:
                    false,

                message:
                    "Unable to update student."

            });

        }

    }
);


/* =========================================================
   ADMIN STUDENTS - DELETE / DEACTIVATE
========================================================= */

app.delete(
    "/api/admin/students/:id",
    authenticateAdmin,

    async (req, res) => {

        try {

            const student =
                await Student.findByIdAndUpdate(

                    req.params.id,

                    {

                        isActive:
                            false

                    },

                    {

                        new:
                            true

                    }

                ).select(
                    "-pinHash"
                );


            if (!student) {

                return res.status(404).json({

                    success:
                        false,

                    message:
                        "Student not found."

                });

            }


            return res.json({

                success:
                    true,

                message:
                    "Student deactivated successfully.",

                student

            });


        } catch (error) {

            console.error(
                "Delete student error:",
                error.message
            );


            return res.status(500).json({

                success:
                    false,

                message:
                    "Unable to deactivate student."

            });

        }

    }
);


/* =========================================================
   ADMIN ATTENDANCE - ALL RECORDS
========================================================= */

app.get(
    "/api/admin/attendance",
    authenticateAdmin,

    async (req, res) => {

        try {

            const date =
                typeof req.query.date ===
                "string"

                    ? req.query.date.trim()

                    : "";


            const filter =
                date
                    ? { date }
                    : {};


            const attendance =
                await Attendance.find(
                    filter
                )
                .populate(
                    "student",
                    "studentCode name course"
                )
                .sort({

                    checkInTime:
                        -1

                });


            return res.json({

                success:
                    true,

                attendance

            });


        } catch (error) {

            console.error(
                "Admin attendance error:",
                error.message
            );


            return res.status(500).json({

                success:
                    false,

                message:
                    "Unable to load attendance."

            });

        }

    }
);


/* =========================================================
   ADMIN ATTENDANCE - STUDENT HISTORY
========================================================= */

app.get(
    "/api/admin/attendance/student/:studentId",
    authenticateAdmin,

    async (req, res) => {

        try {

            const attendance =
                await Attendance.find({

                    student:
                        req.params.studentId

                })
                .sort({

                    checkInTime:
                        -1

                });


            return res.json({

                success:
                    true,

                attendance

            });


        } catch (error) {

            console.error(
                "Student attendance history error:",
                error.message
            );


            return res.status(500).json({

                success:
                    false,

                message:
                    "Unable to load student attendance."

            });

        }

    }
);


/* =========================================================
   ADMIN ACADEMY SETTINGS - GET
========================================================= */

app.get(
    "/api/admin/academy-settings",
    authenticateAdmin,

    async (req, res) => {

        try {

            return res.json({

                success:
                    true,

                settings: {

                    academyName:
                        "PKS Computer Education",

                    latitude:
                        FIXED_ACADEMY_LAT,

                    longitude:
                        FIXED_ACADEMY_LNG,

                    radiusMeters:
                        FIXED_ATTENDANCE_RADIUS_METERS,

                    source:
                        "code"

                }

            });

        } catch (error) {

            console.error(
                "Academy settings error:",
                error.message
            );

            return res.status(500).json({

                success:
                    false,

                message:
                    "Unable to load academy settings."

            });

        }

    }
);


/* =========================================================
   ADMIN ACADEMY SETTINGS - SAVE
========================================================= */

app.post(
    "/api/admin/academy-settings",
    authenticateAdmin,

    async (req, res) => {

        try {

            // The academy location is intentionally fixed in server code.
            // Any latitude/longitude sent by the browser is ignored so that
            // a device's current GPS location can never replace the academy.
            const settings =
                await AcademySettings.findOneAndUpdate(

                    {},

                    {

                        academyName:
                            "PKS Computer Education",

                        latitude:
                            FIXED_ACADEMY_LAT,

                        longitude:
                            FIXED_ACADEMY_LNG,

                        radiusMeters:
                            FIXED_ATTENDANCE_RADIUS_METERS,

                        updatedAt:
                            new Date(),

                        updatedBy:
                            req.admin.adminId

                    },

                    {

                        new:
                            true,

                        upsert:
                            true,

                        setDefaultsOnInsert:
                            true,

                        runValidators:
                            true

                    }

                );

            return res.json({

                success:
                    true,

                message:
                    "Academy attendance location is fixed and saved successfully.",

                settings: {

                    academyName:
                        settings.academyName,

                    latitude:
                        FIXED_ACADEMY_LAT,

                    longitude:
                        FIXED_ACADEMY_LNG,

                    radiusMeters:
                        FIXED_ATTENDANCE_RADIUS_METERS,

                    source:
                        "code"

                }

            });

        } catch (error) {

            console.error(
                "Save academy settings error:",
                error.message
            );

            return res.status(500).json({

                success:
                    false,

                message:
                    "Unable to save academy settings."

            });

        }

    }
);


/* =========================================================
   INQUIRIES - PUBLIC
========================================================= */

app.post(
    "/api/inquiries",
    inquiryLimiter,

    async (req, res) => {

        try {

            const name =
                typeof req.body.name ===
                "string"

                    ? req.body.name.trim()

                    : "";


            const phone =
                typeof req.body.phone ===
                "string"

                    ? req.body.phone.trim()

                    : "";


            const email =
                typeof req.body.email ===
                "string"

                    ? req.body.email.trim()

                    : "";


            const course =
                typeof req.body.course ===
                "string"

                    ? req.body.course.trim()

                    : "";


            const message =
                typeof req.body.message ===
                "string"

                    ? req.body.message.trim()

                    : "";


            if (
                !name ||
                !phone ||
                !message
            ) {

                return res.status(400).json({

                    success:
                        false,

                    message:
                        "Name, phone and message are required."

                });

            }


            if (
                name.length >
                100
            ) {

                return res.status(400).json({

                    success:
                        false,

                    message:
                        "Name is too long."

                });

            }


            if (
                phone.length >
                30
            ) {

                return res.status(400).json({

                    success:
                        false,

                    message:
                        "Phone number is too long."

                });

            }


            if (
                email.length >
                150
            ) {

                return res.status(400).json({

                    success:
                        false,

                    message:
                        "Email is too long."

                });

            }


            if (
                course.length >
                100
            ) {

                return res.status(400).json({

                    success:
                        false,

                    message:
                        "Course name is too long."

                });

            }


            if (
                message.length >
                1000
            ) {

                return res.status(400).json({

                    success:
                        false,

                    message:
                        "Message is too long."

                });

            }


            const inquiry =
                await Inquiry.create({

                    name,

                    phone,

                    email,

                    course,

                    message,

                    status:
                        "new"

                });


            return res.status(201).json({

                success:
                    true,

                message:
                    "Your inquiry has been submitted successfully.",

                inquiryId:
                    inquiry._id

            });


        } catch (error) {

            console.error(
                "Inquiry error:",
                error.message
            );


            return res.status(500).json({

                success:
                    false,

                message:
                    "Unable to submit your inquiry."

            });

        }

    }
);


/* =========================================================
   ADMIN INQUIRIES
========================================================= */

app.get(
    "/api/admin/inquiries",
    authenticateAdmin,

    async (req, res) => {

        try {

            const inquiries =
                await Inquiry.find()
                    .sort({

                        createdAt:
                            -1

                    });


            return res.json({

                success:
                    true,

                inquiries

            });


        } catch (error) {

            console.error(
                "Admin inquiries error:",
                error.message
            );


            return res.status(500).json({

                success:
                    false,

                message:
                    "Unable to load inquiries."

            });

        }

    }
);


/* =========================================================
   ADMIN INQUIRY UPDATE
========================================================= */

app.patch(
    "/api/admin/inquiries/:id",
    authenticateAdmin,

    async (req, res) => {

        try {

            const status =
                typeof req.body.status ===
                "string"

                    ? req.body.status
                        .trim()
                        .toLowerCase()

                    : undefined;


            const updates =
                {};


            if (
                status !==
                undefined
            ) {

                const allowedStatuses = [

                    "new",

                    "contacted",

                    "closed"

                ];


                if (
                    !allowedStatuses.includes(
                        status
                    )
                ) {

                    return res.status(400).json({

                        success:
                            false,

                        message:
                            "Invalid inquiry status."

                    });

                }


                updates.status =
                    status;

            }


            if (
                req.body.notes !==
                undefined
            ) {

                updates.notes =
                    typeof req.body.notes ===
                    "string"

                        ? req.body.notes.trim()

                        : "";

            }


            const inquiry =
                await Inquiry.findByIdAndUpdate(

                    req.params.id,

                    updates,

                    {

                        new:
                            true,

                        runValidators:
                            true

                    }

                );


            if (!inquiry) {

                return res.status(404).json({

                    success:
                        false,

                    message:
                        "Inquiry not found."

                });

            }


            return res.json({

                success:
                    true,

                inquiry

            });


        } catch (error) {

            console.error(
                "Inquiry update error:",
                error.message
            );


            return res.status(500).json({

                success:
                    false,

                message:
                    "Unable to update inquiry."

            });

        }

    }
);


/* =========================================================
   STUDENT LOGIN
========================================================= */

app.post(
    "/api/student/login",
    studentLoginLimiter,

    async (req, res) => {

        try {

            const studentCode =
                typeof req.body.studentCode ===
                "string"

                    ? req.body.studentCode
                        .trim()
                        .toUpperCase()

                    : "";


            const pin =
                typeof req.body.pin ===
                "string"

                    ? req.body.pin.trim()

                    : "";


            if (
                !studentCode ||
                !pin
            ) {

                return res.status(400).json({

                    success:
                        false,

                    message:
                        "Student code and PIN are required."

                });

            }


            const student =
                await Student.findOne({

                    studentCode,

                    isActive:
                        true

                });


            if (!student) {

                return res.status(401).json({

                    success:
                        false,

                    message:
                        "Invalid student code or PIN."

                });

            }


            const validPin =
                await bcrypt.compare(

                    pin,

                    student.pinHash

                );


            if (!validPin) {

                return res.status(401).json({

                    success:
                        false,

                    message:
                        "Invalid student code or PIN."

                });

            }


            const token =
                jwt.sign(

                    {

                        studentId:
                            student._id.toString(),

                        studentCode:
                            student.studentCode,

                        type:
                            "student"

                    },

                    process.env.JWT_SECRET,

                    {

                        expiresIn:
                            "12h",

                        issuer:
                            "pks-foundation"

                    }

                );


            return res.json({

                success:
                    true,

                message:
                    "Student login successful.",

                token,

                expiresIn:
                    43200,

                student:
                    safeStudent(
                        student
                    )

            });


        } catch (error) {

            console.error(
                "Student login error:",
                error.message
            );


            return res.status(500).json({

                success:
                    false,

                message:
                    "Unable to process student login."

            });

        }

    }
);


/* =========================================================
   STUDENT SESSION
========================================================= */

app.get(
    "/api/student/me",
    authenticateStudent,

    async (req, res) => {

        try {

            const student =
                await Student.findById(
                    req.student.studentId
                )
                .select("-pinHash");


            if (
                !student ||
                !student.isActive
            ) {

                return res.status(401).json({

                    success:
                        false,

                    message:
                        "Student account is inactive or unavailable."

                });

            }


            return res.json({

                success:
                    true,

                student

            });


        } catch (error) {

            console.error(
                "Student session error:",
                error.message
            );


            return res.status(500).json({

                success:
                    false,

                message:
                    "Unable to verify student session."

            });

        }

    }
);


/* =========================================================
   STUDENT ATTENDANCE - HISTORY
========================================================= */

app.get(
    "/api/student/attendance",
    authenticateStudent,

    async (req, res) => {

        try {

            const attendance =
                await Attendance.find({

                    student:
                        req.student.studentId

                })
                .sort({

                    checkInTime:
                        -1

                });


            const presentCount =
                attendance.filter(

                    item =>

                        item.status ===
                            "present" ||

                        item.status ===
                            "late"

                ).length;


            const totalDays =
                attendance.length;


            const percentage =
                totalDays > 0

                    ? Number(

                        (

                            (
                                presentCount /
                                totalDays
                            ) * 100

                        ).toFixed(2)

                    )

                    : 0;


            return res.json({

                success:
                    true,

                attendance,

                summary: {

                    totalDays,

                    presentDays:
                        presentCount,

                    absentDays:
                        0,

                    attendancePercentage:
                        percentage

                }

            });


        } catch (error) {

            console.error(
                "Student attendance error:",
                error.message
            );


            return res.status(500).json({

                success:
                    false,

                message:
                    "Unable to load attendance."

            });

        }

    }
);


/* =========================================================
   STUDENT ATTENDANCE - CHECK IN
========================================================= */

app.post(
    "/api/student/attendance/check-in",

    attendanceLimiter,

    authenticateStudent,

    async (req, res) => {

        try {

            const latitude =
                Number(
                    req.body.latitude
                );


            const longitude =
                Number(
                    req.body.longitude
                );


            if (
                !Number.isFinite(
                    latitude
                ) ||
                !Number.isFinite(
                    longitude
                )
            ) {

                return res.status(400).json({

                    success:
                        false,

                    message:
                        "Valid latitude and longitude are required."

                });

            }


            const student =
                await Student.findById(
                    req.student.studentId
                );


            if (
                !student ||
                !student.isActive
            ) {

                return res.status(401).json({

                    success:
                        false,

                    message:
                        "Student account is inactive or unavailable."

                });

            }


            const date =
                getLocalDateString();


            const existing =
                await Attendance.findOne({

                    student:
                        student._id,

                    date

                });


            if (existing) {

                return res.status(409).json({

                    success:
                        false,

                    message:
                        "Attendance has already been marked for today.",

                    attendance:
                        existing

                });

            }


            const academyLocation =
                await getAcademyLocation();


            if (!academyLocation) {

                return res.status(503).json({

                    success:
                        false,

                    message:
                        "Academy attendance location has not been configured yet."

                });

            }


            const distance =
                calculateDistanceMeters(

                    latitude,

                    longitude,

                    academyLocation.latitude,

                    academyLocation.longitude

                );


            if (
                distance >
                academyLocation.radiusMeters
            ) {

                return res.status(403).json({

                    success:
                        false,

                    message:
                        `You are outside the academy attendance area. Your distance is approximately ${Math.round(distance)} meters.`,

                    distanceMeters:
                        Math.round(
                            distance
                        ),

                    allowedRadius:
                        academyLocation.radiusMeters

                });

            }


            const now =
                new Date();


            const attendance =
                await Attendance.create({

                    student:
                        student._id,

                    date,

                    checkInTime:
                        now,

                    latitude,

                    longitude,

                    distanceFromAcademy:
                        Math.round(
                            distance
                        ),

                    allowedRadius:
                        academyLocation.radiusMeters,

                    status:
                        "present"

                });


            return res.status(201).json({

                success:
                    true,

                message:
                    "Attendance marked successfully.",

                attendance

            });


        } catch (error) {

            console.error(
                "Student check-in error:",
                error.message
            );


            if (
                error.code ===
                11000
            ) {

                return res.status(409).json({

                    success:
                        false,

                    message:
                        "Attendance has already been marked for today."

                });

            }


            return res.status(500).json({

                success:
                    false,

                message:
                    "Unable to mark attendance."

            });

        }

    }
);


/* =========================================================
   WEBSITE ROUTES
========================================================= */

app.get(
    "/",
    (req, res) => {

        res.sendFile(

            path.join(

                ROOT,

                "public",

                "index.html"

            )

        );

    }
);


app.get(
    "/about",
    (req, res) => {

        res.sendFile(

            path.join(

                ROOT,

                "public",

                "about.html"

            )

        );

    }
);


app.get(
    "/services",
    (req, res) => {

        res.sendFile(

            path.join(

                ROOT,

                "public",

                "services.html"

            )

        );

    }
);


app.get(
    "/contact",
    (req, res) => {

        res.sendFile(

            path.join(

                ROOT,

                "public",

                "contact.html"

            )

        );

    }
);


app.get(
    "/inquiry",
    (req, res) => {

        res.sendFile(

            path.join(

                ROOT,

                "public",

                "inquiry.html"

            )

        );

    }
);


/* =========================================================
   REVIEWS & RATINGS
========================================================= */


/* =========================================================
   PUBLIC APPROVED REVIEWS
========================================================= */

app.get(
    "/api/reviews",
    async (req, res) => {

        try {

            const reviews =
                await Review.find({

                    status:
                        "approved",

                    isPublic:
                        true

                })
                .select(
                    "studentName rating reviewText createdAt"
                )
                .sort({

                    createdAt:
                        -1

                })
                .limit(50);


            const totalRatings =
                reviews.length;


            const averageRating =
                totalRatings > 0

                    ? Number(

                        (

                            reviews.reduce(

                                (
                                    total,
                                    review
                                ) =>

                                    total +
                                    Number(
                                        review.rating
                                    ),

                                0

                            ) /
                            totalRatings

                        ).toFixed(1)

                    )

                    : 0;


            return res.json({

                success:
                    true,

                reviews,

                averageRating,

                totalRatings

            });


        } catch (error) {

            console.error(
                "Public reviews error:",
                error.message
            );


            return res.status(500).json({

                success:
                    false,

                message:
                    "Unable to load reviews."

            });

        }

    }
);


/* =========================================================
   STUDENT - GET MY REVIEW
========================================================= */

app.get(
    "/api/student/reviews/my",

    authenticateStudent,

    async (req, res) => {

        try {

            const review =
                await Review.findOne({

                    student:
                        req.student.studentId

                })
                .sort({

                    createdAt:
                        -1

                });


            return res.json({

                success:
                    true,

                review:
                    review || null

            });


        } catch (error) {

            console.error(
                "Student review lookup error:",
                error.message
            );


            return res.status(500).json({

                success:
                    false,

                message:
                    "Unable to load your review."

            });

        }

    }
);


/* =========================================================
   STUDENT - SUBMIT REVIEW
========================================================= */

app.post(
    "/api/student/reviews",
    authenticateStudent,
    async (req, res) => {

        try {

            console.log("================================");
            console.log("STUDENT REVIEW SUBMISSION");
            console.log("Student ID:", req.student.studentId);
            console.log("Body:", req.body);

            const rating = Number(req.body.rating);

            const reviewText =
                typeof req.body.reviewText === "string"
                    ? req.body.reviewText.trim()
                    : "";

            if (
                !Number.isInteger(rating) ||
                rating < 1 ||
                rating > 5
            ) {
                return res.status(400).json({
                    success: false,
                    message: "Please select a rating between 1 and 5 stars."
                });
            }

            if (reviewText.length > 1000) {
                return res.status(400).json({
                    success: false,
                    message: "Review cannot exceed 1000 characters."
                });
            }

            const student = await Student.findById(
                req.student.studentId
            );

            if (!student) {
                return res.status(404).json({
                    success: false,
                    message: "Student account was not found."
                });
            }

            if (student.isActive === false) {
                return res.status(401).json({
                    success: false,
                    message: "Student account is inactive."
                });
            }

            /*
             * Check whether this student already has
             * a pending or approved review.
             */
            const existingReview = await Review.findOne({
                student: student._id,
                status: {
                    $in: ["pending", "approved"]
                }
            });

            if (existingReview) {
                return res.status(409).json({
                    success: false,
                    message: "You have already submitted a review."
                });
            }

            /*
             * Create the review.
             */
            const review = new Review({
                student: student._id,

                studentCode:
                    student.studentCode || "",

                studentName:
                    student.name || "Student",

                rating: rating,

                reviewText: reviewText,

                status: "pending",

                isPublic: false
            });

            await review.save();

            console.log(
                "REVIEW SAVED SUCCESSFULLY:",
                review._id
            );

            console.log("================================");

            return res.status(201).json({
                success: true,

                message:
                    "Thank you! Your review has been submitted for administrator approval.",

                review: {
                    id: review._id,

                    studentName:
                        review.studentName,

                    rating:
                        review.rating,

                    reviewText:
                        review.reviewText,

                    status:
                        review.status,

                    isPublic:
                        review.isPublic,

                    createdAt:
                        review.createdAt
                }
            });

        } catch (error) {

            console.error(
                "================================"
            );

            console.error(
                "STUDENT REVIEW ERROR:"
            );

            console.error(
                error
            );

            console.error(
                "================================"
            );

            return res.status(500).json({
                success: false,

                message:
                    "Unable to save your review. Please try again."
            });
        }
    }
);
/* =========================================================
   GLOBAL ERROR HANDLER
========================================================= */

app.use(
    (
        error,
        req,
        res,
        next
    ) => {

        console.error(
            "Server error:",
            error.message
        );

        if (
            res.headersSent
        ) {

            return next(
                error
            );

        }

        res.status(500).json({

            success:
                false,

            message:
                "An unexpected server error occurred."

        });

    }
);


/* =========================================================
   START SERVER
========================================================= */

async function startServer() {

    try {

        console.log("");

        console.log(
            "=========================================="
        );

        console.log(
            "       PKS FOUNDATION WEBSITE"
        );

        console.log(
            "=========================================="
        );

        console.log("");

        console.log(
            "Connecting to MongoDB..."
        );

        await mongoose.connect(
            process.env.MONGODB_URI
        );

        console.log(
            "✅ MongoDB connected"
        );

        const academyLocation =
            await getAcademyLocation();

        app.listen(
            PORT,
            () => {

                console.log("");

                console.log(
                    `✅ Server running on port ${PORT}`
                );

                console.log(
                    `🌐 http://localhost:${PORT}`
                );

                console.log(
                    `🔐 Admin portal: http://localhost:${PORT}/admin/login.html`
                );

                console.log(
                    `🎓 Student portal: http://localhost:${PORT}/student/login.html`
                );

                console.log("");

                if (
                    academyLocation
                ) {

                    console.log(
                        `📍 Attendance geofence: ${academyLocation.radiusMeters} meters (${academyLocation.source})`
                    );

                } else {

                    console.log(
                        "📍 Attendance academy location is fixed in server code."
                    );

                }

                console.log("");

                console.log(
                    "=========================================="
                );

                console.log(
                    "       PKS FOUNDATION READY"
                );

                console.log(
                    "=========================================="
                );

                console.log("");

            }
        );

    } catch (error) {

        console.error("");

        console.error(
            "❌ SERVER STARTUP FAILED"
        );

        console.error("");

        console.error(
            error.message
        );

        console.error("");

        process.exit(1);

    }

}


/* =========================================================
   GRACEFUL SHUTDOWN
========================================================= */

async function shutdown() {

    try {

        await mongoose.connection.close();

        console.log("");

        console.log(
            "✅ MongoDB connection closed."
        );

        process.exit(0);

    } catch (error) {

        console.error(
            "❌ Error closing MongoDB connection:",
            error.message
        );

        process.exit(1);

    }

}


process.on(
    "SIGINT",
    shutdown
);

process.on(
    "SIGTERM",
    shutdown
);


/* =========================================================
   START
========================================================= */

startServer();