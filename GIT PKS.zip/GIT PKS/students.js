"use strict";

const TOKEN_KEYS = [
    "adminToken",
    "admin_token",
    "pksAdminToken",
    "pks_admin_token",
    "adminAuthToken",
    "admin_auth_token",
    "authToken",
    "token"
];

function getAdminToken() {
    for (const key of TOKEN_KEYS) {
        const local = localStorage.getItem(key);
        if (local) return local;

        const session = sessionStorage.getItem(key);
        if (session) return session;
    }

    return null;
}

function clearAdminTokens() {
    TOKEN_KEYS.forEach(key => {
        localStorage.removeItem(key);
        sessionStorage.removeItem(key);
    });
}

async function apiRequest(endpoint, options = {}) {

    const token = getAdminToken();

    if (!token) {
        window.location.replace("/admin/login.html");
        throw new Error("NO_ADMIN_TOKEN");
    }

    const response = await fetch("/api" + endpoint, {
        ...options,
        headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + token,
            ...(options.headers || {})
        }
    });

    let data = null;

    try {
        data = await response.json();
    } catch {
        data = null;
    }

    /*
     * ONLY a genuine 401 means the login session is invalid.
     * Do not redirect for normal server errors.
     */
    if (response.status === 401) {
        clearAdminTokens();
        window.location.replace("/admin/login.html");
        throw new Error("ADMIN_SESSION_INVALID");
    }

    if (!response.ok) {
        throw new Error(
            data?.message ||
            "Server returned HTTP " + response.status
        );
    }

    return data;
}

let allStudents = [];


/* =========================================================
   LOAD STUDENTS
========================================================= */

async function loadStudents() {

    const tableBody =
        document.getElementById("studentsTableBody");

    if (!tableBody) return;

    tableBody.innerHTML = `
        <tr>
            <td colspan="6" class="empty">
                Loading student records...
            </td>
        </tr>
    `;

    try {

        const data =
            await apiRequest("/admin/students");

        allStudents =
            Array.isArray(data?.students)
                ? data.students
                : [];

        renderStudents();

    } catch (error) {

        console.error("Students loading error:", error);

        if (error.message === "ADMIN_SESSION_INVALID") {
            return;
        }

        tableBody.innerHTML = `
            <tr>
                <td colspan="6" class="empty">
                    Unable to load student records.
                </td>
            </tr>
        `;
    }
}


/* =========================================================
   RENDER
========================================================= */

function renderStudents() {

    const tableBody =
        document.getElementById("studentsTableBody");

    if (!tableBody) return;

    const search =
        (
            document.getElementById("searchInput")?.value ||
            ""
        )
        .trim()
        .toLowerCase();

    const filter =
        document.getElementById("statusFilter")?.value ||
        "all";

    let students = allStudents.filter(student => {

        const active =
            student.isActive !== false;

        if (filter === "active" && !active) {
            return false;
        }

        if (filter === "inactive" && active) {
            return false;
        }

        if (!search) return true;

        const text = [
            student.studentCode,
            student.name,
            student.course,
            student.studentPhone,
            student.fatherPhone,
            student.motherPhone
        ]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();

        return text.includes(search);
    });

    if (students.length === 0) {

        tableBody.innerHTML = `
            <tr>
                <td colspan="6" class="empty">
                    No student records found.
                </td>
            </tr>
        `;

        return;
    }

    tableBody.innerHTML = students.map(student => {

        const active =
            student.isActive !== false;

        return `
            <tr>

                <td>
                    ${escapeHTML(student.studentCode || "—")}
                </td>

                <td>
                    <strong>
                        ${escapeHTML(student.name || "—")}
                    </strong>
                </td>

                <td>
                    ${escapeHTML(student.course || "—")}
                </td>

                <td>
                    ${escapeHTML(student.studentPhone || "—")}
                </td>

                <td>
                    <span class="status ${active ? "active" : "inactive"}">
                        ${active ? "Active" : "Inactive"}
                    </span>
                </td>

                <td>
                    <button
                        type="button"
                        class="view-button"
                        onclick="viewStudent('${student._id}')"
                    >
                        View
                    </button>
                </td>

            </tr>
        `;

    }).join("");
}


/* =========================================================
   VIEW STUDENT
========================================================= */

function viewStudent(id) {

    const student =
        allStudents.find(
            item => String(item._id) === String(id)
        );

    if (!student) return;

    const details = [
        "Student Code: " + (student.studentCode || "—"),
        "Name: " + (student.name || "—"),
        "Course: " + (student.course || "—"),
        "Student Phone: " + (student.studentPhone || "—"),
        "Father: " + (student.fatherName || "—"),
        "Father Phone: " + (student.fatherPhone || "—"),
        "Mother: " + (student.motherName || "—"),
        "Mother Phone: " + (student.motherPhone || "—"),
        "Address: " + (student.address || "—"),
        "Status: " + (
            student.isActive !== false
                ? "Active"
                : "Inactive"
        )
    ].join("\n");

    alert(details);
}


/* =========================================================
   ADD STUDENT
========================================================= */

async function setupStudentForm() {

    const form =
        document.getElementById("studentForm");

    if (!form) return;

    const saveButton =
        document.getElementById("saveButton");

    const message =
        document.getElementById("formMessage");

    form.addEventListener("submit", async function(event) {

        event.preventDefault();

        if (saveButton) {
            saveButton.disabled = true;
            saveButton.textContent = "Saving...";
        }

        if (message) {
            message.className = "message";
            message.textContent = "";
        }

        const payload = {

            studentCode:
                document.getElementById("studentCode")?.value.trim(),

            pin:
                document.getElementById("studentPin")?.value.trim(),

            name:
                document.getElementById("studentName")?.value.trim(),

            course:
                document.getElementById("course")?.value.trim(),

            fatherName:
                document.getElementById("fatherName")?.value.trim(),

            fatherPhone:
                document.getElementById("fatherPhone")?.value.trim(),

            motherName:
                document.getElementById("motherName")?.value.trim(),

            motherPhone:
                document.getElementById("motherPhone")?.value.trim(),

            studentPhone:
                document.getElementById("studentPhone")?.value.trim(),

            address:
                document.getElementById("address")?.value.trim()
        };

        try {

            const data =
                await apiRequest(
                    "/admin/students",
                    {
                        method: "POST",
                        body: JSON.stringify(payload)
                    }
                );

            if (message) {
                message.className =
                    "message success";

                message.textContent =
                    data?.message ||
                    "Student added successfully.";
            }

            form.reset();

            const details =
                document.getElementById(
                    "addStudentDetails"
                );

            if (details) {
                setTimeout(() => {
                    details.removeAttribute("open");
                }, 800);
            }

            await loadStudents();

        } catch (error) {

            console.error("Add student error:", error);

            if (
                error.message ===
                "ADMIN_SESSION_INVALID"
            ) {
                return;
            }

            if (message) {
                message.className =
                    "message error";

                message.textContent =
                    error.message ||
                    "Unable to add student.";
            }

        } finally {

            if (saveButton) {
                saveButton.disabled = false;
                saveButton.textContent = "Save Student";
            }
        }
    });
}


/* =========================================================
   LOGOUT
========================================================= */

function setupLogout() {

    const button =
        document.getElementById("logoutButton");

    if (!button) return;

    button.addEventListener("click", function() {

        clearAdminTokens();

        window.location.replace(
            "/admin/login.html"
        );
    });
}


/* =========================================================
   SEARCH / FILTER
========================================================= */

function setupFilters() {

    document
        .getElementById("searchInput")
        ?.addEventListener(
            "input",
            renderStudents
        );

    document
        .getElementById("statusFilter")
        ?.addEventListener(
            "change",
            renderStudents
        );
}


/* =========================================================
   ESCAPE HTML
========================================================= */

function escapeHTML(value) {

    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}


/* =========================================================
   START
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    async function() {

        setupLogout();
        setupFilters();
        setupStudentForm();

        /*
         * Verify session WITHOUT automatically redirecting
         * unless the backend actually returns HTTP 401.
         */
        const token = getAdminToken();

        if (!token) {
            window.location.replace(
                "/admin/login.html"
            );
            return;
        }

        await loadStudents();
    }
);