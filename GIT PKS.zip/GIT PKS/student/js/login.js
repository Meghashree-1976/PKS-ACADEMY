/* =========================================================
   PKS FOUNDATION
   STUDENT PORTAL LOGIN
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {

    console.log("==========================================");
    console.log("🎓 PKS FOUNDATION STUDENT LOGIN");
    console.log("==========================================");


    const form = document.querySelector("form");

    if (!form) {
        console.error("❌ Student login form not found.");
        return;
    }


    const studentCodeInput =
        document.getElementById("studentCode") ||
        document.querySelector('[name="studentCode"]');


    const pinInput =
        document.getElementById("studentPin") ||
        document.getElementById("pin") ||
        document.querySelector('[name="pin"]');


    const loginButton =
        form.querySelector('button[type="submit"]') ||
        form.querySelector("button");


    if (!studentCodeInput) {
        console.error("❌ Student Code input not found.");
    }

    if (!pinInput) {
        console.error("❌ Student PIN input not found.");
    }


    /* =====================================================
       MESSAGE BOX
    ===================================================== */

    let messageBox =
        document.getElementById("loginMessage");


    if (!messageBox) {

        messageBox =
            document.createElement("div");

        messageBox.id =
            "loginMessage";

        messageBox.style.marginTop =
            "16px";

        messageBox.style.padding =
            "12px 16px";

        messageBox.style.borderRadius =
            "10px";

        messageBox.style.fontSize =
            "14px";

        messageBox.style.fontWeight =
            "700";

        messageBox.style.textAlign =
            "center";

        messageBox.style.display =
            "none";

        form.appendChild(
            messageBox
        );
    }


    /* =====================================================
       SHOW MESSAGE
    ===================================================== */

    function showMessage(
        message,
        type = "error"
    ) {

        messageBox.textContent =
            message;

        messageBox.style.display =
            "block";


        if (type === "success") {

            messageBox.style.background =
                "#e8f7ee";

            messageBox.style.color =
                "#18753c";

            messageBox.style.border =
                "1px solid #b8e5c8";

        } else {

            messageBox.style.background =
                "#fff0f0";

            messageBox.style.color =
                "#b42318";

            messageBox.style.border =
                "1px solid #f1c1c1";
        }
    }


    /* =====================================================
       LOGIN
    ===================================================== */

    form.addEventListener(
        "submit",
        async function (event) {

            event.preventDefault();


            console.log("");
            console.log("🎓 STUDENT LOGIN SUBMITTED");
            console.log("------------------------------------------");


            if (
                !studentCodeInput ||
                !pinInput
            ) {

                showMessage(
                    "Login fields are missing. Please refresh the page."
                );

                return;
            }


            const studentCode =
                String(
                    studentCodeInput.value || ""
                )
                .trim()
                .toUpperCase();


            const pin =
                String(
                    pinInput.value || ""
                )
                .trim();


            console.log(
                "Student Code:",
                studentCode
            );

            console.log(
                "PIN entered:",
                pin ? "YES" : "NO"
            );


            /* =================================================
               VALIDATION
            ================================================= */

            if (!studentCode) {

                showMessage(
                    "Please enter your Student Code."
                );

                studentCodeInput.focus();

                return;
            }


            if (!pin) {

                showMessage(
                    "Please enter your Student PIN."
                );

                pinInput.focus();

                return;
            }


            /* =================================================
               BUTTON
            ================================================= */

            const originalText =
                loginButton
                    ? loginButton.textContent
                    : "Login";


            if (loginButton) {

                loginButton.disabled =
                    true;

                loginButton.textContent =
                    "Signing in...";
            }


            showMessage(
                "Checking your student account...",
                "success"
            );


            /* =================================================
               REQUEST
            ================================================= */

            try {

                console.log(
                    "📡 POST /api/student/login"
                );


                const response =
                    await fetch(
                        "/api/student/login",
                        {
                            method: "POST",

                            headers: {
                                "Content-Type":
                                    "application/json"
                            },

                            body:
                                JSON.stringify({

                                    studentCode:
                                        studentCode,

                                    pin:
                                        pin

                                })
                        }
                    );


                console.log(
                    "Response status:",
                    response.status
                );


                let data;


                try {

                    data =
                        await response.json();

                } catch (jsonError) {

                    console.error(
                        "❌ Invalid JSON response",
                        jsonError
                    );

                    showMessage(
                        "The server returned an invalid response."
                    );

                    return;
                }


                console.log(
                    "Server response:",
                    data
                );


                /* =================================================
                   SUCCESS
                ================================================= */

                if (
                    response.ok &&
                    data.success === true &&
                    data.token
                ) {

                    console.log("");
                    console.log(
                        "✅ LOGIN SUCCESSFUL"
                    );

                    console.log(
                        "Student:",
                        data.student
                    );


                    /* =================================================
                       IMPORTANT
                       Dashboard uses pksStudentToken
                    ================================================= */

                    localStorage.setItem(
                        "pksStudentToken",
                        data.token
                    );


                    /* Also keep these for compatibility */
                    localStorage.setItem(
                        "studentToken",
                        data.token
                    );


                    if (data.student) {

                        localStorage.setItem(
                            "studentData",
                            JSON.stringify(
                                data.student
                            )
                        );
                    }


                    showMessage(
                        "Login successful! Opening Student Portal...",
                        "success"
                    );


                    /* =================================================
                       REDIRECT
                    ================================================= */

                    setTimeout(
                        function () {

                            window.location.href =
                                "/student/dashboard.html";

                        },
                        500
                    );


                    return;
                }


                /* =================================================
                   FAILED LOGIN
                ================================================= */

                console.error(
                    "❌ LOGIN FAILED"
                );

                console.error(
                    data.message
                );


                showMessage(
                    data.message ||
                    "Invalid Student Code or PIN."
                );


            } catch (error) {

                console.error(
                    "❌ STUDENT LOGIN CONNECTION ERROR",
                    error
                );


                showMessage(
                    "Unable to connect to the PKS Foundation server. Make sure the server is running."
                );


            } finally {

                if (loginButton) {

                    loginButton.disabled =
                        false;

                    loginButton.textContent =
                        originalText ||
                        "Login";
                }
            }

        }
    );

});