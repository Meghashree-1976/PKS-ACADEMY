/* =========================================================
   PKS FOUNDATION
   ADMISSION INQUIRY JAVASCRIPT
========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    const form =
        document.getElementById("inquiryForm");

    const statusBox =
        document.getElementById("inquiryStatus");

    const submitButton =
        document.getElementById("submitInquiry");

    const message =
        document.getElementById("message");

    const messageCount =
        document.getElementById("messageCount");

    const currentYear =
        document.getElementById("currentYear");


    /* =====================================================
       YEAR
    ===================================================== */

    if (currentYear) {
        currentYear.textContent =
            new Date().getFullYear();
    }


    /* =====================================================
       MESSAGE COUNTER
    ===================================================== */

    if (message && messageCount) {

        const updateCount = () => {

            messageCount.textContent =
                message.value.length;

        };

        message.addEventListener(
            "input",
            updateCount
        );

        updateCount();
    }


    /* =====================================================
       FORM SUBMISSION
    ===================================================== */

    if (!form) {
        return;
    }


    form.addEventListener(
        "submit",
        async (event) => {

            event.preventDefault();


            if (statusBox) {

                statusBox.className =
                    "inq-status";

                statusBox.textContent = "";

            }


            if (submitButton) {

                submitButton.disabled = true;

                submitButton.querySelector("span")
                    .textContent =
                    "Submitting...";

            }


            const formData =
                new FormData(form);

            const payload = {

                name:
                    String(
                        formData.get("name") || ""
                    ).trim(),

                phone:
                    String(
                        formData.get("phone") || ""
                    ).trim(),

                email:
                    String(
                        formData.get("email") || ""
                    ).trim(),

                course:
                    String(
                        formData.get("course") || ""
                    ).trim(),

                message:
                    String(
                        formData.get("message") || ""
                    ).trim()

            };


            try {

                const response =
                    await fetch(
                        "/api/inquiries",
                        {
                            method: "POST",

                            headers: {
                                "Content-Type":
                                    "application/json"
                            },

                            body:
                                JSON.stringify(
                                    payload
                                )
                        }
                    );


                const data =
                    await response.json();


                if (!response.ok || !data.success) {

                    throw new Error(
                        data.message ||
                        "Unable to submit your enquiry."
                    );

                }


                if (statusBox) {

                    statusBox.className =
                        "inq-status success";

                    statusBox.textContent =
                        "Your enquiry has been submitted successfully. The PKS Foundation team can contact you with further information.";

                }


                form.reset();


                if (messageCount) {
                    messageCount.textContent = "0";
                }


            } catch (error) {

                if (statusBox) {

                    statusBox.className =
                        "inq-status error";

                    statusBox.textContent =
                        error.message ||
                        "Something went wrong. Please try again.";

                }

            } finally {

                if (submitButton) {

                    submitButton.disabled = false;

                    submitButton.querySelector("span")
                        .textContent =
                        "Submit Inquiry";

                }

            }

        }
    );

});