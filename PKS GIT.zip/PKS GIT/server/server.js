﻿require("dotenv").config();

const express = require("express");
const path = require("path");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");

const Inquiry = require("../database/models/Inquiry");
const Admin = require("../database/models/Admin");
const Student = require("../database/models/Student");
const Attendance = require("../database/models/Attendance");
const AcademySettings = require("../database/models/AcademySettings");
const Review = require("../database/models/Review");

const app = express();

const PORT = Number(process.env.PORT) || 5000;
const ROOT = path.join(__dirname, "..");

/* =========================================================
   ATTENDANCE LOCATION SETTINGS
========================================================= */

const FIXED_ACADEMY_LAT = 14.216399;
const FIXED_ACADEMY_LNG = 76.408972;
const FIXED_ATTENDANCE_RADIUS_METERS = 100;

const ACADEMY_LAT = FIXED_ACADEMY_LAT;
const ACADEMY_LNG = FIXED_ACADEMY_LNG;
const ATTENDANCE_RADIUS_METERS = FIXED_ATTENDANCE_RADIUS_METERS;

const TIME_ZONE =
    process.env.TIME_ZONE || "Asia/Kolkata";

/* =========================================================
   ENVIRONMENT CHECK
========================================================= */

if (!process.env.MONGODB_URI) {
    console.error("❌ MONGODB_URI is missing from .env");
    process.exit(1);
}

if (!process.env.JWT_SECRET) {
    console.error("❌ JWT_SECRET is missing from .env");
    process.exit(1);
}

if (process.env.JWT_SECRET.length < 32) {
    console.error("❌ JWT_SECRET must be at least 32 characters.");
    process.exit(1);
}

/* =========================================================
   SECURITY
========================================================= */

app.disable("x-powered-by");

app.use(
    helmet({
        crossOriginResourcePolicy: {
            policy: "cross-origin"
        }
    })
);

/* =========================================================
   BODY PARSING
========================================================= */

app.use(
    express.json({
        limit: "100kb"
    })
);

app.use(
    express.urlencoded({
        extended: true,
        limit: "100kb"
    })
);

/* =========================================================
   STATIC FILES
========================================================= */

app.use(
    express.static(
        path.join(ROOT, "public")
    )
);

app.use(
    "/admin",
    express.static(
        path.join(ROOT, "admin")
    )
);

app.use(
    "/student",
    express.static(
        path.join(ROOT, "student")
    )
);

// WEBSITE ROUTES

app.get("/about", (req, res) => {
    res.sendFile(path.join(ROOT, "public", "about.html"));
});

app.get("/services", (req, res) => {
    res.sendFile(path.join(ROOT, "public", "services.html"));
});

app.get("/contact", (req, res) => {
    res.sendFile(path.join(ROOT, "public", "contact.html"));
});

app.get("/inquiry", (req, res) => {
    res.sendFile(path.join(ROOT, "public", "inquiry.html"));
});

/* =========================================================
   RATE LIMITING
========================================================= */

const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 10,
    standardHeaders: true,
    legacyHeaders: false,
    message: {
        success: false,
        message:
            "Too many login attempts. Please try again later."
    }
});

const studentLoginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 15,
    standardHeaders: true,
    legacyHeaders: false,
    message: {
        success: false,
        message:
            "Too many student login attempts. Please try again later."
    }
});

const inquiryLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 20,
    standardHeaders: true,
    legacyHeaders: false,
    message: {
        success: false,
        message:
            "Too many inquiries. Please try again later."
    }
});

const attendanceLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 20,
    standardHeaders: true,
    legacyHeaders: false,
    message: {
        success: false,
        message:
            "Too many attendance attempts. Please try again later."
    }
});

/* =========================================================
   ADMIN AUTHENTICATION
========================================================= */

function authenticateAdmin(req, res, next) {
    try {
        const header = req.headers.authorization;

        if (
            !header ||
            !header.startsWith("Bearer ")
        ) {
            return res.status(401).json({
                success: false,
                message:
                    "Administrator authentication required."
            });
        }

        const token = header.substring(7);

        const decoded = jwt.verify(
            token,
            process.env.JWT_SECRET,
            {
                issuer: "pks-foundation"
            }
        );

        if (
            !decoded ||
            decoded.type !== "admin" ||
            !decoded.adminId
        ) {
            return res.status(401).json({
                success: false,
                message:
                    "Invalid administrator authentication token."
            });
        }

        req.admin = decoded;

        next();
    } catch (error) {
        if (
            error.name ===
            "TokenExpiredError"
        ) {
            return res.status(401).json({
                success: false,
                message:
                    "Administrator session expired. Please log in again."
            });
        }

        return res.status(401).json({
            success: false,
            message:
                "Invalid administrator authentication token."
        });
    }
}

/* =========================================================
   STUDENT AUTHENTICATION
========================================================= */

function authenticateStudent(req, res, next) {
    try {
        const header = req.headers.authorization;

        if (
            !header ||
            !header.startsWith("Bearer ")
        ) {
            return res.status(401).json({
                success: false,
                message:
                    "Student authentication required."
            });
        }

        const token = header.substring(7);

        const decoded = jwt.verify(
            token,
            process.env.JWT_SECRET,
            {
                issuer: "pks-foundation"
            }
        );

        if (
            !decoded ||
            decoded.type !== "student" ||
            !decoded.studentId
        ) {
            return res.status(401).json({
                success: false,
                message:
                    "Invalid student authentication token."
            });
        }

        req.student = decoded;

        next();
    } catch (error) {
        if (
            error.name ===
            "TokenExpiredError"
        ) {
            return res.status(401).json({
                success: false,
                message:
                    "Student session expired. Please log in again."
            });
        }

        return res.status(401).json({
            success: false,
            message:
                "Invalid student authentication token."
        });
    }
}

/* =========================================================
   HELPER FUNCTIONS
========================================================= */

function getLocalDateString(
    date = new Date()
) {
    const formatter =
        new Intl.DateTimeFormat(
            "en-CA",
            {
                timeZone: TIME_ZONE,
                year: "numeric",
                month: "2-digit",
                day: "2-digit"
            }
        );

    return formatter.format(date);
}

function isValidCoordinate(value) {
    return Number.isFinite(
        Number(value)
    );
}

function calculateDistanceMeters(
    lat1,
    lng1,
    lat2,
    lng2
) {
    const earthRadius = 6371000;

    const toRadians = degrees =>
        degrees * Math.PI / 180;

    const dLat = toRadians(
        lat2 - lat1
    );

    const dLng = toRadians(
        lng2 - lng1
    );

    const a =
        Math.sin(dLat / 2) ** 2 +
        Math.cos(
            toRadians(lat1)
        ) *
        Math.cos(
            toRadians(lat2)
        ) *
        Math.sin(dLng / 2) ** 2;

    const c =
        2 *
        Math.atan2(
            Math.sqrt(a),
            Math.sqrt(1 - a)
        );

    return earthRadius * c;
}

function safeStudent(student) {
    const data =
        student.toObject
            ? student.toObject()
            : { ...student };

    delete data.pinHash;

    return data;
}

async function getAcademyLocation() {
    return {
        latitude: FIXED_ACADEMY_LAT,
        longitude: FIXED_ACADEMY_LNG,
        radiusMeters:
            FIXED_ATTENDANCE_RADIUS_METERS,
        academyName:
            "PKS Computer Education",
        source: "code",
        updatedAt: null
    };
}

/* =========================================================
   HEALTH CHECK
========================================================= */

app.get(
    "/api/health",
    (req, res) => {
        res.json({
            success: true,
            message:
                "PKS Foundation server is running.",
            database:
                mongoose.connection.readyState === 1
                    ? "connected"
                    : "disconnected",
            timestamp:
                new Date().toISOString()
        });
    }
);

/* =========================================================
   ADMIN LOGIN
========================================================= */

app.post(
    "/api/admin/login",
    loginLimiter,
    async (req, res) => {
        try {
            const username =
                typeof req.body.username === "string"
                    ? req.body.username
                        .trim()
                        .toLowerCase()
                    : "";

            const password =
                typeof req.body.password === "string"
                    ? req.body.password
                    : "";

            if (
                !username ||
                !password
            ) {
                return res.status(400).json({
                    success: false,
                    message:
                        "Username and password are required."
                });
            }

            const admin =
                await Admin.findOne({
                    username,
                    isActive: true
                });

            if (!admin) {
                return res.status(401).json({
                    success: false,
                    message:
                        "Invalid username or password."
                });
            }

            const validPassword =
                await bcrypt.compare(
                    password,
                    admin.passwordHash
                );

            if (!validPassword) {
                return res.status(401).json({
                    success: false,
                    message:
                        "Invalid username or password."
                });
            }

            const token = jwt.sign(
                {
                    adminId:
                        admin._id.toString(),
                    username:
                        admin.username,
                    role:
                        admin.role,
                    type: "admin"
                },
                process.env.JWT_SECRET,
                {
                    expiresIn: "8h",
                    issuer:
                        "pks-foundation"
                }
            );

            return res.json({
                success: true,
                message:
                    "Login successful.",
                token,
                expiresIn: 28800,
                admin: {
                    id: admin._id,
                    username:
                        admin.username,
                    name:
                        admin.name,
                    role:
                        admin.role
                }
            });
        } catch (error) {
            console.error(
                "Admin login error:",
                error
            );

            return res.status(500).json({
                success: false,
                message:
                    "Unable to process login."
            });
        }
    }
);

/* =========================================================
   ADMIN SESSION
========================================================= */

app.get(
    "/api/admin/me",
    authenticateAdmin,
    async (req, res) => {
        try {
            const admin =
                await Admin.findById(
                    req.admin.adminId
                ).select(
                    "_id username name role isActive"
                );

            if (
                !admin ||
                !admin.isActive
            ) {
                return res.status(401).json({
                    success: false,
                    message:
                        "Administrator account is inactive."
                });
            }

            return res.json({
                success: true,
                admin: {
                    id: admin._id,
                    username:
                        admin.username,
                    name:
                        admin.name,
                    role:
                        admin.role
                }
            });
        } catch (error) {
            console.error(
                "Admin session error:",
                error
            );

            return res.status(500).json({
                success: false,
                message:
                    "Unable to verify session."
            });
        }
    }
);

/* =========================================================
   ADMIN DASHBOARD
========================================================= */

app.get(
    "/api/admin/dashboard",
    authenticateAdmin,
    async (req, res) => {
        try {
            const date =
                getLocalDateString();

            const totalStudents =
                await Student.countDocuments({
                    isActive: true
                });

            const presentToday =
                await Attendance.countDocuments({
                    date,
                    status: {
                        $in: [
                            "present",
                            "late"
                        ]
                    }
                });

            const absentToday =
                Math.max(
                    totalStudents -
                    presentToday,
                    0
                );

            const newInquiries =
                await Inquiry.countDocuments({
                    status: "new"
                });

            return res.json({
                success: true,
                data: {
                    totalStudents,
                    presentToday,
                    absentToday,
                    newInquiries,
                    date
                }
            });
        } catch (error) {
            console.error(
                "Dashboard error:",
                error
            );

            return res.status(500).json({
                success: false,
                message:
                    "Unable to load dashboard."
            });
        }
    }
);

/* =========================================================
   ADMIN STUDENTS - GET ALL
========================================================= */

app.get(
    "/api/admin/students",
    authenticateAdmin,
    async (req, res) => {
        try {
            const students =
                await Student.find()
                    .select("-pinHash")
                    .sort({
                        createdAt: -1
                    });

            return res.json({
                success: true,
                students
            });
        } catch (error) {
            console.error(
                "Get students error:",
                error
            );

            return res.status(500).json({
                success: false,
                message:
                    "Unable to load students."
            });
        }
    }
);

/* =========================================================
   ADMIN STUDENTS - CREATE
========================================================= */

app.post(
    "/api/admin/students",
    authenticateAdmin,
    async (req, res) => {
        try {
            const studentCode =
                typeof req.body.studentCode === "string"
                    ? req.body.studentCode
                        .trim()
                        .toUpperCase()
                    : "";

            const name =
                typeof req.body.name === "string"
                    ? req.body.name.trim()
                    : "";

            const pin =
                typeof req.body.pin === "string"
                    ? req.body.pin.trim()
                    : "";

            const fatherName =
                typeof req.body.fatherName === "string"
                    ? req.body.fatherName.trim()
                    : "";

            const fatherPhone =
                typeof req.body.fatherPhone === "string"
                    ? req.body.fatherPhone.trim()
                    : "";

            const motherName =
                typeof req.body.motherName === "string"
                    ? req.body.motherName.trim()
                    : "";

            const motherPhone =
                typeof req.body.motherPhone === "string"
                    ? req.body.motherPhone.trim()
                    : "";

            const studentPhone =
                typeof req.body.studentPhone === "string"
                    ? req.body.studentPhone.trim()
                    : "";

            const address =
                typeof req.body.address === "string"
                    ? req.body.address.trim()
                    : "";

            const course =
                typeof req.body.course === "string"
                    ? req.body.course.trim()
                    : "";

            if (
                !studentCode ||
                !name ||
                !pin
            ) {
                return res.status(400).json({
                    success: false,
                    message:
                        "Student code, name and PIN are required."
                });
            }

            if (
                pin.length < 4 ||
                pin.length > 20
            ) {
                return res.status(400).json({
                    success: false,
                    message:
                        "PIN must be between 4 and 20 characters."
                });
            }

            const existing =
                await Student.findOne({
                    studentCode
                });

            if (existing) {
                return res.status(409).json({
                    success: false,
                    message:
                        "A student with this code already exists."
                });
            }

            const pinHash =
                await bcrypt.hash(
                    pin,
                    12
                );

            const student =
                await Student.create({
                    studentCode,
                    name,
                    pinHash,
                    fatherName,
                    fatherPhone,
                    motherName,
                    motherPhone,
                    studentPhone,
                    address,
                    course,
                    isActive: true
                });

            return res.status(201).json({
                success: true,
                message:
                    "Student created successfully.",
                student:
                    safeStudent(student)
            });
        } catch (error) {
            console.error(
                "Create student error:",
                error
            );

            if (
                error.code === 11000
            ) {
                return res.status(409).json({
                    success: false,
                    message:
                        "Student code already exists."
                });
            }

            return res.status(500).json({
                success: false,
                message:
                    "Unable to create student."
            });
        }
    }
);

/* =========================================================
   ADMIN STUDENTS - UPDATE
========================================================= */

app.patch(
    "/api/admin/students/:id",
    authenticateAdmin,
    async (req, res) => {
        try {
            const student =
                await Student.findById(
                    req.params.id
                );

            if (!student) {
                return res.status(404).json({
                    success: false,
                    message:
                        "Student not found."
                });
            }

            const fields = [
                "name",
                "course",
                "fatherName",
                "fatherPhone",
                "motherName",
                "motherPhone",
                "studentPhone",
                "address",
                "isActive"
            ];

            for (
                const field of fields
            ) {
                if (
                    req.body[field] !==
                    undefined
                ) {
                    student[field] =
                        req.body[field];
                }
            }

            if (
                typeof req.body.pin ===
                "string" &&
                req.body.pin.trim()
            ) {
                const pin =
                    req.body.pin.trim();

                if (
                    pin.length < 4 ||
                    pin.length > 20
                ) {
                    return res.status(400).json({
                        success: false,
                        message:
                            "PIN must be between 4 and 20 characters."
                    });
                }

                student.pinHash =
                    await bcrypt.hash(
                        pin,
                        12
                    );
            }

            await student.save();

            return res.json({
                success: true,
                message:
                    "Student updated successfully.",
                student:
                    safeStudent(student)
            });
        } catch (error) {
            console.error(
                "Update student error:",
                error
            );

            return res.status(500).json({
                success: false,
                message:
                    "Unable to update student."
            });
        }
    }
);

/* =========================================================
   PUBLIC INQUIRY - CREATE
========================================================= */

app.post(
    "/api/inquiries",
    inquiryLimiter,
    async (req, res) => {
        try {
            const name =
                typeof req.body.name === "string"
                    ? req.body.name.trim()
                    : "";

            const phone =
                typeof req.body.phone === "string"
                    ? req.body.phone.trim()
                    : "";

            const email =
                typeof req.body.email === "string"
                    ? req.body.email.trim()
                    : "";

            const course =
                typeof req.body.course === "string"
                    ? req.body.course.trim()
                    : "";

            const message =
                typeof req.body.message === "string"
                    ? req.body.message.trim()
                    : "";

            if (
                !name ||
                !phone ||
                !course ||
                !message
            ) {
                return res.status(400).json({
                    success: false,
                    message:
                        "Name, phone, course and message are required."
                });
            }

            const inquiry =
                await Inquiry.create({
                    name,
                    phone,
                    email,
                    course,
                    message,
                    status: "new"
                });

            return res.status(201).json({
                success: true,
                message:
                    "Your inquiry has been submitted successfully.",
                inquiryId:
                    inquiry._id
            });
        } catch (error) {
            console.error(
                "Create inquiry error:",
                error
            );

            return res.status(500).json({
                success: false,
                message:
                    "Unable to submit inquiry."
            });
        }
    }
);

/* =========================================================
   ADMIN INQUIRIES - GET ALL
========================================================= */

app.get(
    "/api/admin/inquiries",
    authenticateAdmin,
    async (req, res) => {
        try {
            const inquiries =
                await Inquiry.find()
                    .sort({
                        createdAt: -1
                    });

            return res.json({
                success: true,
                inquiries
            });
        } catch (error) {
            console.error(
                "Get inquiries error:",
                error
            );

            return res.status(500).json({
                success: false,
                message:
                    "Unable to load inquiries."
            });
        }
    }
);

/* =========================================================
   ADMIN INQUIRIES - UPDATE STATUS
========================================================= */

app.patch(
    "/api/admin/inquiries/:id",
    authenticateAdmin,
    async (req, res) => {
        try {
            const inquiryId =
                req.params.id;

            const status =
                String(
                    req.body.status || ""
                )
                    .trim()
                    .toLowerCase();

            const allowedStatuses = [
                "new",
                "contacted",
                "closed"
            ];

            console.log(
                "===================================="
            );

            console.log(
                "INQUIRY STATUS UPDATE"
            );

            console.log(
                "Inquiry ID:",
                inquiryId
            );

            console.log(
                "Requested status:",
                status
            );

            console.log(
                "===================================="
            );

            if (
                !allowedStatuses.includes(
                    status
                )
            ) {
                return res.status(400).json({
                    success: false,
                    message:
                        "Invalid inquiry status."
                });
            }

            const inquiry =
                await Inquiry.findById(
                    inquiryId
                );

            if (!inquiry) {
                return res.status(404).json({
                    success: false,
                    message:
                        "Inquiry not found."
                });
            }

            inquiry.status =
                status;

            await inquiry.save();

            console.log(
                "✅ Inquiry updated:",
                inquiry._id.toString(),
                "=>",
                inquiry.status
            );

            return res.json({
                success: true,
                message:
                    "Inquiry status updated successfully.",
                inquiry
            });
        } catch (error) {
            console.error(
                "❌ Inquiry status update error:",
                error
            );

            return res.status(500).json({
                success: false,
                message:
                    "Unable to update inquiry status."
            });
        }
    }
);

/* =========================================================
   STUDENT LOGIN
========================================================= */

app.post(
    "/api/student/login",
    studentLoginLimiter,
    async (req, res) => {
        try {
            const studentCode =
                typeof req.body.studentCode === "string"
                    ? req.body.studentCode
                        .trim()
                        .toUpperCase()
                    : "";

            const pin =
                typeof req.body.pin === "string"
                    ? req.body.pin.trim()
                    : "";

            if (
                !studentCode ||
                !pin
            ) {
                return res.status(400).json({
                    success: false,
                    message:
                        "Student code and PIN are required."
                });
            }

            const student =
                await Student.findOne({
                    studentCode,
                    isActive: true
                });

            if (!student) {
                return res.status(401).json({
                    success: false,
                    message:
                        "Invalid student code or PIN."
                });
            }

            const validPin =
                await bcrypt.compare(
                    pin,
                    student.pinHash
                );

            if (!validPin) {
                return res.status(401).json({
                    success: false,
                    message:
                        "Invalid student code or PIN."
                });
            }

            const token =
                jwt.sign(
                    {
                        studentId:
                            student._id.toString(),
                        studentCode:
                            student.studentCode,
                        type: "student"
                    },
                    process.env.JWT_SECRET,
                    {
                        expiresIn: "8h",
                        issuer:
                            "pks-foundation"
                    }
                );

            return res.json({
                success: true,
                message:
                    "Student login successful.",
                token,
                expiresIn: 28800,
                student:
                    safeStudent(student)
            });
        } catch (error) {
            console.error(
                "Student login error:",
                error
            );

            return res.status(500).json({
                success: false,
                message:
                    "Unable to process student login."
            });
        }
    }
);

/* =========================================================
   STUDENT SESSION
========================================================= */

app.get(
    "/api/student/me",
    authenticateStudent,
    async (req, res) => {
        try {
            const student =
                await Student.findById(
                    req.student.studentId
                ).select(
                    "-pinHash"
                );

            if (
                !student ||
                !student.isActive
            ) {
                return res.status(401).json({
                    success: false,
                    message:
                        "Student account is inactive."
                });
            }

            return res.json({
                success: true,
                student
            });
        } catch (error) {
            console.error(
                "Student session error:",
                error
            );

            return res.status(500).json({
                success: false,
                message:
                    "Unable to verify student session."
            });
        }
    }
);

/* =========================================================
   ACADEMY LOCATION
========================================================= */

app.get(
    "/api/academy/location",
    async (req, res) => {
        try {
            const location =
                await getAcademyLocation();

            return res.json({
                success: true,
                location
            });
        } catch (error) {
            console.error(
                "Academy location error:",
                error
            );

            return res.status(500).json({
                success: false,
                message:
                    "Unable to load academy location."
            });
        }
    }
);

/* =========================================================
   STUDENT ATTENDANCE - TODAY
========================================================= */

app.get(
    "/api/student/attendance",
    authenticateStudent,
    async (req, res) => {
        try {
            const date =
                getLocalDateString();

            const attendance =
                await Attendance.find({
                    student:
                        req.student.studentId
                })
                    .sort({
                        date: -1,
                        createdAt: -1
                    })
                    .limit(100);

            const today =
                attendance.find(
                    item =>
                        item.date ===
                        date
                ) || null;

            return res.json({
                success: true,
                date,
                today,
                attendance
            });
        } catch (error) {
            console.error(
                "Student attendance error:",
                error
            );

            return res.status(500).json({
                success: false,
                message:
                    "Unable to load attendance."
            });
        }
    }
);

/* =========================================================
   STUDENT MARK ATTENDANCE
========================================================= */

app.post(
    "/api/student/attendance",
    attendanceLimiter,
    authenticateStudent,
    async (req, res) => {
        try {
            const latitude =
                Number(
                    req.body.latitude
                );

            const longitude =
                Number(
                    req.body.longitude
                );

            if (
                !isValidCoordinate(
                    latitude
                ) ||
                !isValidCoordinate(
                    longitude
                )
            ) {
                return res.status(400).json({
                    success: false,
                    message:
                        "Valid location coordinates are required."
                });
            }

            const distance =
                calculateDistanceMeters(
                    latitude,
                    longitude,
                    ACADEMY_LAT,
                    ACADEMY_LNG
                );

            if (
                distance >
                ATTENDANCE_RADIUS_METERS
            ) {
                return res.status(403).json({
                    success: false,
                    message:
                        "You are outside the PKS Computer Education attendance area.",
                    distanceMeters:
                        Math.round(distance),
                    allowedRadiusMeters:
                        ATTENDANCE_RADIUS_METERS
                });
            }

            const date =
                getLocalDateString();

            const existing =
                await Attendance.findOne({
                    student:
                        req.student.studentId,
                    date
                });

            if (existing) {
                return res.status(409).json({
                    success: false,
                    message:
                        "Attendance has already been marked for today.",
                    attendance:
                        existing
                });
            }

            const attendance =
                await Attendance.create({
                    student:
                        req.student.studentId,
                    date,
                    status: "present",
                    latitude,
                    longitude,
                    distanceMeters:
                        Math.round(distance)
                });

            return res.status(201).json({
                success: true,
                message:
                    "Attendance marked successfully.",
                attendance
            });
        } catch (error) {
            console.error(
                "Mark attendance error:",
                error
            );

            return res.status(500).json({
                success: false,
                message:
                    "Unable to mark attendance."
            });
        }
    }
);

/* =========================================================
   ADMIN ATTENDANCE - GET
========================================================= */

app.get(
    "/api/admin/attendance",
    authenticateAdmin,
    async (req, res) => {
        try {
            const date =
                typeof req.query.date === "string" &&
                req.query.date.trim()
                    ? req.query.date.trim()
                    : getLocalDateString();

            const attendance =
                await Attendance.find({
                    date
                })
                    .populate(
                        "student",
                        "studentCode name course studentPhone"
                    )
                    .sort({
                        createdAt: -1
                    });

            return res.json({
                success: true,
                date,
                attendance
            });
        } catch (error) {
            console.error(
                "Admin attendance error:",
                error
            );

            return res.status(500).json({
                success: false,
                message:
                    "Unable to load attendance."
            });
        }
    }
);

/* =========================================================
   REVIEWS - PUBLIC
========================================================= */

app.get(
    "/api/reviews/public",
    async (req, res) => {
        try {
            const reviews =
                await Review.find({
                    status: "approved"
                })
                    .sort({
                        createdAt: -1
                    });

            return res.json({
                success: true,
                reviews
            });
        } catch (error) {
            console.error(
                "Public reviews error:",
                error
            );

            return res.status(500).json({
                success: false,
                message:
                    "Unable to load reviews."
            });
        }
    }
);

/* =========================================================
   REVIEWS - ADMIN GET
========================================================= */

app.get(
    "/api/admin/reviews",
    authenticateAdmin,
    async (req, res) => {
        try {
            const reviews =
                await Review.find()
                    .sort({
                        createdAt: -1
                    });

            return res.json({
                success: true,
                reviews
            });
        } catch (error) {
            console.error(
                "Admin reviews error:",
                error
            );

            return res.status(500).json({
                success: false,
                message:
                    "Unable to load reviews."
            });
        }
    }
);

/* =========================================================
   REVIEWS - ADMIN UPDATE
========================================================= */

app.patch(
    "/api/admin/reviews/:id",
    authenticateAdmin,
    async (req, res) => {
        try {
            const status =
                String(
                    req.body.status || ""
                )
                    .trim()
                    .toLowerCase();

            const allowedStatuses = [
                "pending",
                "approved",
                "rejected"
            ];

            if (
                !allowedStatuses.includes(
                    status
                )
            ) {
                return res.status(400).json({
                    success: false,
                    message:
                        "Invalid review status."
                });
            }

            const review =
                await Review.findById(
                    req.params.id
                );

            if (!review) {
                return res.status(404).json({
                    success: false,
                    message:
                        "Review not found."
                });
            }

            review.status =
                status;

            await review.save();

            return res.json({
                success: true,
                message:
                    "Review updated successfully.",
                review
            });
        } catch (error) {
            console.error(
                "Review update error:",
                error
            );

            return res.status(500).json({
                success: false,
                message:
                    "Unable to update review."
            });
        }
    }
);

/* =========================================================
   ACADEMY SETTINGS
========================================================= */

app.get(
    "/api/academy/settings",
    async (req, res) => {
        try {
            const settings =
                await AcademySettings.findOne();

            return res.json({
                success: true,
                settings:
                    settings || {}
            });
        } catch (error) {
            console.error(
                "Academy settings error:",
                error
            );

            return res.status(500).json({
                success: false,
                message:
                    "Unable to load academy settings."
            });
        }
    }
);

/* =========================================================
   404 API HANDLER
========================================================= */

app.use(
    "/api",
    (req, res) => {
        return res.status(404).json({
            success: false,
            message:
                "API endpoint not found."
        });
    }
);

/* =========================================================
   GENERAL ERROR HANDLER
========================================================= */

app.use(
    (error, req, res, next) => {
        console.error(
            "Unhandled server error:",
            error
        );

        return res.status(500).json({
            success: false,
            message:
                "Internal server error."
        });
    }
);

/* =========================================================
   START SERVER
========================================================= */

async function startServer() {
    try {
        console.log("Connecting to MongoDB...");

        await mongoose.connect(
            process.env.MONGODB_URI
        );

        console.log(
            "✅ MongoDB connected"
        );

        app.listen(
            PORT,
            () => {
                console.log(
                    "=============================================="
                );

                console.log(
                    "✅ PKS Foundation Server Running"
                );

                console.log(
                    "🌐 http://localhost:" +
                    PORT
                );

                console.log(
                    "🔐 Admin: http://localhost:" +
                    PORT +
                    "/admin/login.html"
                );

                console.log(
                    "🎓 Student: http://localhost:" +
                    PORT +
                    "/student/login.html"
                );

                console.log(
                    "📍 Attendance geofence: " +
                    ATTENDANCE_RADIUS_METERS +
                    " meters"
                );

                console.log(
                    "=============================================="
                );
            }
        );
    } catch (error) {
        console.error(
            "❌ Server startup failed:"
        );

        console.error(
            error
        );

        process.exit(1);
    }
}

startServer();