require("dotenv").config();

const mongoose = require("mongoose");

const AcademySettings = require("../database/models/AcademySettings");


/* =========================================================
   PKS COMPUTER EDUCATION
   FIXED ATTENDANCE LOCATION
========================================================= */

const ACADEMY_NAME =
    "PKS Computer Education";

const LATITUDE =
    14.216399;

const LONGITUDE =
    76.408972;

const RADIUS_METERS =
    100;


/* =========================================================
   VALIDATION
========================================================= */

if (!process.env.MONGODB_URI) {

    console.error("");
    console.error("❌ MONGODB_URI is missing from .env");
    console.error("");

    process.exit(1);

}


/* =========================================================
   SAVE LOCATION
========================================================= */

async function setAcademyLocation() {

    try {

        console.log("");
        console.log("==========================================");
        console.log("   PKS ACADEMY LOCATION CONFIGURATION");
        console.log("==========================================");
        console.log("");

        console.log("Connecting to MongoDB...");

        await mongoose.connect(
            process.env.MONGODB_URI
        );

        console.log("✅ MongoDB connected");
        console.log("");

        const settings =
            await AcademySettings.findOneAndUpdate(

                {},

                {
                    academyName:
                        ACADEMY_NAME,

                    latitude:
                        LATITUDE,

                    longitude:
                        LONGITUDE,

                    radiusMeters:
                        RADIUS_METERS,

                    updatedAt:
                        new Date()

                },

                {
                    new:
                        true,

                    upsert:
                        true,

                    setDefaultsOnInsert:
                        true,

                    runValidators:
                        true

                }

            );


        console.log(
            "✅ Academy location saved successfully."
        );

        console.log("");

        console.log(
            "Academy:",
            settings.academyName
        );

        console.log(
            "Latitude:",
            settings.latitude
        );

        console.log(
            "Longitude:",
            settings.longitude
        );

        console.log(
            "Radius:",
            settings.radiusMeters,
            "meters"
        );

        console.log("");

        console.log(
            "=========================================="
        );

        console.log(
            "   ATTENDANCE LOCATION READY"
        );

        console.log(
            "=========================================="
        );

        console.log("");

        console.log(
            "Students can now be checked"
        );

        console.log(
            "against this fixed academy location."
        );

        console.log("");

    }

    catch (error) {

        console.error("");

        console.error(
            "❌ FAILED TO SAVE ACADEMY LOCATION"
        );

        console.error("");

        console.error(
            error.message
        );

        console.error("");

        process.exitCode =
            1;

    }

    finally {

        await mongoose.connection.close();

    }

}


setAcademyLocation();