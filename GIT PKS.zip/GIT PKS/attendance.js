const mongoose = require("mongoose");

const attendanceSchema = new mongoose.Schema(
    {
        student: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Student",
            required: true
        },

        date: {
            type: String,
            required: true
        },

        checkInTime: {
            type: Date,
            required: true
        },

        latitude: {
            type: Number,
            required: true
        },

        longitude: {
            type: Number,
            required: true
        },

        distanceFromAcademy: {
            type: Number,
            required: true
        },

        status: {
            type: String,
            enum: ["present", "late", "rejected"],
            default: "present"
        }
    },
    {
        timestamps: true
    }
);

attendanceSchema.index(
    {
        student: 1,
        date: 1
    },
    {
        unique: true
    }
);

module.exports = mongoose.model("Attendance", attendanceSchema);