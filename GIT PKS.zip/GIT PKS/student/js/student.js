const API_BASE = "/api";

const token = localStorage.getItem("pksStudentToken");

if (!token) {
    window.location.href = "/student/login.html";
}

/* =========================================================
   GLOBAL DATA
========================================================= */

let currentStudent = null;
let attendanceRecords = [];
let selectedRating = 0;
let myReview = null;

/* =========================================================
   API REQUEST
========================================================= */

async function apiRequest(url, options = {}) {

    const response = await fetch(`${API_BASE}${url}`, {
        ...options,

        headers: {
            ...(options.body
                ? { "Content-Type": "application/json" }
                : {}),

            ...(options.headers || {}),

            Authorization: `Bearer ${token}`
        }
    });

    if (response.status === 401 || response.status === 403) {

        localStorage.removeItem("pksStudentToken");

        window.location.href =
            "/student/login.html";

        return;
    }

    let data;

    try {
        data = await response.json();
    } catch {
        throw new Error("Invalid server response.");
    }

    if (!response.ok) {

        throw new Error(
            data.message ||
            data.error ||
            "Something went wrong."
        );
    }

    return data;
}

/* =========================================================
   HELPERS
========================================================= */

function safeText(value) {

    if (
        value === null ||
        value === undefined ||
        String(value).trim() === ""
    ) {
        return "—";
    }

    return String(value);
}

function formatDate(value) {

    if (!value) {
        return "—";
    }

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        return "—";
    }

    return date.toLocaleDateString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric"
    });
}

function formatTime(value) {

    if (!value) {
        return "—";
    }

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        return "—";
    }

    return date.toLocaleTimeString("en-IN", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: true
    });
}

function escapeHTML(value) {

    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

/* =========================================================
   STUDENT PROFILE
========================================================= */

async function loadStudentProfile() {

    try {

        const data =
            await apiRequest("/student/me");

        if (!data || !data.student) {

            throw new Error(
                "Student information was not returned."
            );
        }

        currentStudent =
            data.student;

        console.log(
            "PKS Student Profile:",
            currentStudent
        );

        renderStudentProfile(
            currentStudent
        );

    } catch (error) {

        console.error(
            "Student profile error:",
            error
        );
    }
}

function renderStudentProfile(student) {

    const name =
        student.name ||
        student.studentName ||
        "Student";

    const code =
        student.studentCode ||
        "—";

    const course =
        student.course ||
        "—";

    const phone =
        student.studentPhone ||
        student.phone ||
        "—";

    const father =
        student.fatherName ||
        "—";

    const mother =
        student.motherName ||
        "—";

    const address =
        student.address ||
        "—";

    /* HEADER */

    const headerName =
        document.getElementById(
            "headerStudentName"
        );

    if (headerName) {
        headerName.textContent = name;
    }

    const headerCode =
        document.getElementById(
            "headerStudentCode"
        );

    if (headerCode) {
        headerCode.textContent = code;
    }

    const avatar =
        document.getElementById(
            "studentAvatar"
        );

    if (avatar) {

        avatar.textContent =
            name.trim()
                .charAt(0)
                .toUpperCase() || "S";
    }

    /* WELCOME */

    const welcomeName =
        document.getElementById(
            "welcomeStudentName"
        );

    if (welcomeName) {
        welcomeName.textContent = name;
    }

    /* PROFILE */

    const profileName =
        document.getElementById(
            "profileName"
        );

    if (profileName) {
        profileName.textContent =
            safeText(name);
    }

    const profileCode =
        document.getElementById(
            "profileCode"
        );

    if (profileCode) {
        profileCode.textContent =
            safeText(code);
    }

    const profileCourse =
        document.getElementById(
            "profileCourse"
        );

    if (profileCourse) {
        profileCourse.textContent =
            safeText(course);
    }

    const studentPhone =
        document.getElementById(
            "studentPhone"
        );

    if (studentPhone) {
        studentPhone.textContent =
            safeText(phone);
    }

    const fatherName =
        document.getElementById(
            "fatherName"
        );

    if (fatherName) {
        fatherName.textContent =
            safeText(father);
    }

    const motherName =
        document.getElementById(
            "motherName"
        );

    if (motherName) {
        motherName.textContent =
            safeText(mother);
    }

    const studentAddress =
        document.getElementById(
            "studentAddress"
        );

    if (studentAddress) {
        studentAddress.textContent =
            safeText(address);
    }
}

/* =========================================================
   ATTENDANCE
========================================================= */

async function loadAttendance() {

    try {

        const data =
            await apiRequest(
                "/student/attendance"
            );

        attendanceRecords =
            data?.attendance ||
            data?.records ||
            data?.data ||
            [];

        if (!Array.isArray(attendanceRecords)) {
            attendanceRecords = [];
        }

        console.log(
            "PKS Attendance:",
            attendanceRecords
        );

        renderAttendance();

    } catch (error) {

        console.error(
            "Attendance loading error:",
            error
        );

        attendanceRecords = [];

        renderAttendance();
    }
}

function getAttendanceDate(record) {

    return (
        record.date ||
        record.attendanceDate ||
        record.checkInTime ||
        record.checkedInAt ||
        record.createdAt
    );
}

function getCheckInTime(record) {

    return (
        record.checkInTime ||
        record.checkedInAt ||
        record.checkIn ||
        record.createdAt
    );
}

function getStatus(record) {

    if (record.status) {
        return record.status;
    }

    if (record.present === true) {
        return "Present";
    }

    return "Present";
}

function getDistance(record) {

    if (
        record.distanceMeters !== undefined &&
        record.distanceMeters !== null
    ) {

        return `${Math.round(
            record.distanceMeters
        )} m`;
    }

    if (
        record.distance !== undefined &&
        record.distance !== null
    ) {

        return `${Math.round(
            record.distance
        )} m`;
    }

    return "—";
}

function getGPS(record) {

    if (
        record.latitude !== undefined &&
        record.longitude !== undefined
    ) {

        return (
            `${Number(record.latitude).toFixed(5)}, ` +
            `${Number(record.longitude).toFixed(5)}`
        );
    }

    if (record.location) {
        return record.location;
    }

    return "—";
}

function renderAttendance() {

    const totalDays =
        attendanceRecords.length;

    const presentDays =
        attendanceRecords.filter(record => {

            const status =
                String(
                    getStatus(record)
                ).toLowerCase();

            return (
                status === "present" ||
                status === "late" ||
                status === "approved" ||
                status === "checked-in"
            );

        }).length;

    const percentage =
        totalDays > 0
            ? (presentDays / totalDays) * 100
            : 0;

    /* SUMMARY */

    const percentageElement =
        document.getElementById(
            "attendancePercentage"
        );

    if (percentageElement) {

        percentageElement.textContent =
            `${percentage.toFixed(1)}%`;
    }

    const presentElement =
        document.getElementById(
            "presentDays"
        );

    if (presentElement) {
        presentElement.textContent =
            presentDays;
    }

    const totalElement =
        document.getElementById(
            "totalDays"
        );

    if (totalElement) {
        totalElement.textContent =
            totalDays;
    }

    /* TABLE */

    const tableBody =
        document.getElementById(
            "attendanceTableBody"
        );

    if (!tableBody) {
        return;
    }

    if (attendanceRecords.length === 0) {

        tableBody.innerHTML = `
            <tr>
                <td colspan="5">
                    <div class="empty-state">
                        No attendance records found.
                    </div>
                </td>
            </tr>
        `;

        return;
    }

    tableBody.innerHTML =
        attendanceRecords
            .map(record => {

                const status =
                    getStatus(record);

                const statusLower =
                    String(status)
                        .toLowerCase();

                let statusClass =
                    "status-present";

                if (statusLower === "late") {

                    statusClass =
                        "status-late";
                }

                if (
                    statusLower === "rejected"
                ) {

                    statusClass =
                        "status-rejected";
                }

                return `
                    <tr>

                        <td>
                            ${escapeHTML(
                                formatDate(
                                    getAttendanceDate(
                                        record
                                    )
                                )
                            )}
                        </td>

                        <td>
                            ${escapeHTML(
                                formatTime(
                                    getCheckInTime(
                                        record
                                    )
                                )
                            )}
                        </td>

                        <td>
                            <span
                                class="status-badge ${statusClass}"
                            >
                                ${escapeHTML(
                                    status
                                )}
                            </span>
                        </td>

                        <td>
                            ${escapeHTML(
                                getDistance(
                                    record
                                )
                            )}
                        </td>

                        <td>
                            <span class="location-text">
                                ${escapeHTML(
                                    getGPS(
                                        record
                                    )
                                )}
                            </span>
                        </td>

                    </tr>
                `;
            })
            .join("");
}

/* =========================================================
   CHECK IF ALREADY ATTENDED TODAY
========================================================= */

function attendedToday() {

    const today =
        new Date();

    return attendanceRecords.some(
        record => {

            const value =
                getAttendanceDate(
                    record
                );

            if (!value) {
                return false;
            }

            const date =
                new Date(value);

            return (
                date.getFullYear() ===
                    today.getFullYear() &&

                date.getMonth() ===
                    today.getMonth() &&

                date.getDate() ===
                    today.getDate()
            );
        }
    );
}

/* =========================================================
   ATTENDANCE MESSAGE
========================================================= */

function showAttendanceMessage(
    message,
    type = "info"
) {

    const element =
        document.getElementById(
            "attendanceMessage"
        );

    if (!element) {
        return;
    }

    element.textContent =
        message;

    element.className =
        `attendance-message ${type}`;
}

function hideAttendanceMessage() {

    const element =
        document.getElementById(
            "attendanceMessage"
        );

    if (!element) {
        return;
    }

    element.textContent = "";

    element.className =
        "attendance-message";
}

/* =========================================================
   GPS CHECK-IN
========================================================= */

async function checkInAttendance() {

    const button =
        document.getElementById(
            "checkInButton"
        );

    hideAttendanceMessage();

    if (attendedToday()) {

        showAttendanceMessage(
            "You have already marked attendance today.",
            "info"
        );

        return;
    }

    if (!navigator.geolocation) {

        showAttendanceMessage(
            "GPS is not supported by this browser.",
            "error"
        );

        return;
    }

    if (button) {

        button.disabled = true;

        button.textContent =
            "Getting Location...";
    }

    showAttendanceMessage(
        "Getting your current location...",
        "info"
    );

    navigator.geolocation.getCurrentPosition(

        async position => {

            try {

                const latitude =
                    position.coords.latitude;

                const longitude =
                    position.coords.longitude;

                console.log(
                    "Student GPS:",
                    {
                        latitude,
                        longitude,
                        accuracy:
                            position.coords.accuracy
                    }
                );

                if (button) {

                    button.textContent =
                        "Marking Attendance...";
                }

                showAttendanceMessage(
                    "Checking your location...",
                    "info"
                );

                await apiRequest(
                    "/student/attendance/check-in",
                    {
                        method: "POST",

                        body: JSON.stringify({
                            latitude,
                            longitude
                        })
                    }
                );

                showAttendanceMessage(
                    "Attendance marked successfully! ✅",
                    "success"
                );

                await loadAttendance();

            } catch (error) {

                console.error(
                    "Check-in error:",
                    error
                );

                showAttendanceMessage(
                    error.message ||
                    "Unable to mark attendance.",
                    "error"
                );

            } finally {

                if (button) {

                    button.disabled = false;

                    button.textContent =
                        "Mark Attendance";
                }
            }
        },

        error => {

            console.error(
                "GPS error:",
                error
            );

            let message =
                "Unable to get your location.";

            if (error.code === 1) {

                message =
                    "Location permission was denied. Please allow location access for this website.";
            }

            if (error.code === 2) {

                message =
                    "Your current location could not be determined.";
            }

            if (error.code === 3) {

                message =
                    "Location request timed out. Please try again.";
            }

            showAttendanceMessage(
                message,
                "error"
            );

            if (button) {

                button.disabled = false;

                button.textContent =
                    "Mark Attendance";
            }
        },

        {
            enableHighAccuracy: true,
            timeout: 15000,
            maximumAge: 0
        }
    );
}

/* =========================================================
   IMPORTANT:
   CONNECT MARK ATTENDANCE BUTTON
========================================================= */

function initializeAttendance() {

    const button =
        document.getElementById(
            "checkInButton"
        );

    if (!button) {

        console.error(
            "PKS: checkInButton was not found."
        );

        return;
    }

    console.log(
        "PKS: Mark Attendance button connected."
    );

    button.addEventListener(
        "click",
        checkInAttendance
    );
}

/* =========================================================
   REVIEW
========================================================= */

function initializeReview() {

    const stars =
        document.querySelectorAll(
            ".review-star"
        );

    stars.forEach(star => {

        star.addEventListener(
            "click",
            () => {

                selectedRating =
                    Number(
                        star.dataset.rating
                    );

                updateStars();
            }
        );
    });

    const reviewForm =
        document.getElementById(
            "reviewForm"
        );

    if (reviewForm) {

        reviewForm.addEventListener(
            "submit",
            async event => {

                event.preventDefault();

                await submitReview();
            }
        );
    }

    const reviewText =
        document.getElementById(
            "reviewText"
        );

    if (reviewText) {

        reviewText.addEventListener(
            "input",
            updateCharacterCount
        );

        updateCharacterCount();
    }
}

function updateStars() {

    const stars =
        document.querySelectorAll(
            ".review-star"
        );

    stars.forEach(star => {

        const rating =
            Number(
                star.dataset.rating
            );

        const selected =
            rating <= selectedRating;

        star.classList.toggle(
            "selected",
            selected
        );

        star.setAttribute(
            "aria-pressed",
            selected
                ? "true"
                : "false"
        );
    });
}

function updateCharacterCount() {

    const textarea =
        document.getElementById(
            "reviewText"
        );

    const counter =
        document.getElementById(
            "reviewCharCount"
        );

    if (!textarea || !counter) {
        return;
    }

    counter.textContent =
        `${textarea.value.length} / 1000`;
}

async function loadMyReview() {

    try {

        const data =
            await apiRequest(
                "/student/reviews/my"
            );

        myReview =
            data?.review ||
            data?.data ||
            null;

        renderReviewStatus();

        if (myReview) {

            selectedRating =
                Number(
                    myReview.rating
                ) || 0;

            const textarea =
                document.getElementById(
                    "reviewText"
                );

            if (textarea) {

                textarea.value =
                    myReview.reviewText ||
                    "";
            }

            updateStars();
            updateCharacterCount();
        }

    } catch (error) {

        console.error(
            "Review loading error:",
            error
        );
    }
}

function renderReviewStatus() {

    const container =
        document.getElementById(
            "reviewStatus"
        );

    if (!container) {
        return;
    }

    if (!myReview) {

        container.innerHTML = "";

        return;
    }

    const status =
        myReview.status ||
        "pending";

    let message = "";
    let className = "info";

    if (status === "pending") {

        message =
            "Your review is waiting for administrator approval.";

        className = "pending";

    } else if (status === "approved") {

        message =
            "Your review has been approved and is now public. ⭐";

        className = "approved";

    } else if (status === "rejected") {

        message =
            "Your review was rejected. You may submit another review.";

        className = "rejected";
    }

    container.innerHTML = `
        <div class="review-status ${className}">
            ${escapeHTML(message)}
        </div>
    `;
}

async function submitReview() {

    const reviewTextElement =
        document.getElementById(
            "reviewText"
        );

    const submitButton =
        document.getElementById(
            "reviewSubmitButton"
        );

    const reviewText =
        reviewTextElement
            ? reviewTextElement.value.trim()
            : "";

    if (
        selectedRating < 1 ||
        selectedRating > 5
    ) {

        alert(
            "Please select a rating from 1 to 5 stars."
        );

        return;
    }

    if (reviewText.length > 1000) {

        alert(
            "Your review must be 1000 characters or less."
        );

        return;
    }

    try {

        if (submitButton) {

            submitButton.disabled = true;

            submitButton.textContent =
                "Submitting...";
        }

        const data =
            await apiRequest(
                "/student/reviews",
                {
                    method: "POST",

                    body: JSON.stringify({
                        rating:
                            selectedRating,

                        reviewText
                    })
                }
            );

        myReview =
            data?.review ||
            data?.data ||
            null;

        renderReviewStatus();

        alert(
            "Your review has been submitted successfully! ⭐"
        );

    } catch (error) {

        console.error(
            "Review submission error:",
            error
        );

        alert(
            error.message ||
            "Unable to submit your review."
        );

    } finally {

        if (submitButton) {

            submitButton.disabled = false;

            submitButton.textContent =
                "Submit Review";
        }
    }
}

/* =========================================================
   LOGOUT
========================================================= */

function initializeLogout() {

    const logoutButton =
        document.getElementById(
            "logoutButton"
        );

    if (!logoutButton) {
        return;
    }

    logoutButton.addEventListener(
        "click",
        () => {

            localStorage.removeItem(
                "pksStudentToken"
            );

            window.location.href =
                "/student/login.html";
        }
    );
}

/* =========================================================
   SIDEBAR NAVIGATION
========================================================= */

function initializeNavigation() {

    const links =
        document.querySelectorAll(
            ".sidebar-link[data-section]"
        );

    const sections =
        document.querySelectorAll(
            ".portal-section"
        );

    links.forEach(link => {

        link.addEventListener(
            "click",
            () => {

                links.forEach(item => {

                    item.classList.remove(
                        "active"
                    );
                });

                link.classList.add(
                    "active"
                );
            }
        );
    });

    const observer =
        new IntersectionObserver(
            entries => {

                entries.forEach(entry => {

                    if (!entry.isIntersecting) {
                        return;
                    }

                    const id =
                        entry.target.id;

                    links.forEach(link => {

                        link.classList.toggle(
                            "active",
                            link.dataset.section === id
                        );
                    });
                });
            },
            {
                rootMargin:
                    "-100px 0px -60% 0px"
            }
        );

    sections.forEach(section => {
        observer.observe(section);
    });
}

/* =========================================================
   START
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    async () => {

        console.log(
            "PKS Student Portal loaded."
        );

        initializeLogout();

        initializeNavigation();

        initializeAttendance();

        initializeReview();

        await loadStudentProfile();

        await loadAttendance();

        await loadMyReview();
    }
);