/* =========================================================
   PKS FOUNDATION
   STUDENT REVIEW SYSTEM - FINAL FIX
========================================================= */

(function () {

    "use strict";

    const API_BASE = "/api";

    function getToken() {

        const possibleKeys = [
            "studentToken",
            "student_token",
            "pksStudentToken",
            "token",
            "authToken",
            "studentAuthToken"
        ];

        for (const key of possibleKeys) {

            const value = localStorage.getItem(key);

            if (value) {
                return value;
            }
        }

        return null;
    }

    function getElement(id) {
        return document.getElementById(id);
    }

    function showMessage(message, success) {

        let box =
            getElement("reviewMessage");

        if (!box) {

            box =
                document.createElement("div");

            box.id =
                "reviewMessage";

            box.style.marginTop =
                "15px";

            box.style.padding =
                "12px 16px";

            box.style.borderRadius =
                "10px";

            box.style.fontWeight =
                "600";

            const button =
                getElement("reviewSubmitButton");

            if (button && button.parentElement) {

                button.parentElement.appendChild(box);

            } else {

                document.body.appendChild(box);
            }
        }

        box.textContent =
            message;

        box.style.display =
            "block";

        box.style.background =
            success
                ? "#dcfce7"
                : "#fee2e2";

        box.style.color =
            success
                ? "#166534"
                : "#991b1b";
    }

    function setStars(rating) {

        document
            .querySelectorAll(".review-star")
            .forEach(function (star) {

                const value =
                    Number(
                        star.dataset.rating
                    );

                if (value <= rating) {

                    star.classList.add(
                        "selected"
                    );

                    star.style.color =
                        "#f59e0b";

                } else {

                    star.classList.remove(
                        "selected"
                    );

                    star.style.color =
                        "";
                }
            });
    }

    function initializeStars() {

        const stars =
            document.querySelectorAll(
                ".review-star"
            );

        if (!stars.length) {
            return;
        }

        stars.forEach(function (star) {

            star.addEventListener(
                "click",
                function () {

                    const rating =
                        Number(
                            star.dataset.rating
                        );

                    window.pksSelectedRating =
                        rating;

                    setStars(rating);
                }
            );

            star.addEventListener(
                "mouseenter",
                function () {

                    const rating =
                        Number(
                            star.dataset.rating
                        );

                    setStars(rating);
                }
            );
        });

        const container =
            stars[0].parentElement;

        if (container) {

            container.addEventListener(
                "mouseleave",
                function () {

                    setStars(
                        window.pksSelectedRating || 0
                    );
                }
            );
        }
    }

    async function loadMyReview() {

        const token =
            getToken();

        if (!token) {
            return;
        }

        try {

            const response =
                await fetch(
                    API_BASE +
                    "/student/reviews/my",
                    {
                        method: "GET",
                        headers: {
                            "Authorization":
                                "Bearer " + token
                        },
                        cache: "no-store"
                    }
                );

            if (!response.ok) {
                return;
            }

            const data =
                await response.json();

            if (
                !data ||
                !data.success ||
                !data.review
            ) {
                return;
            }

            const review =
                data.review;

            window.pksSelectedRating =
                Number(
                    review.rating || 0
                );

            setStars(
                window.pksSelectedRating
            );

            const text =
                getElement(
                    "reviewText"
                );

            if (text) {

                text.value =
                    review.reviewText || "";

                text.disabled =
                    true;
            }

            const button =
                getElement(
                    "reviewSubmitButton"
                );

            if (button) {

                button.disabled =
                    true;

                button.textContent =
                    review.status ===
                    "approved"
                        ? "Review Approved"
                        : review.status ===
                          "rejected"
                            ? "Review Rejected"
                            : "Review Submitted";
            }

            showMessage(
                review.status === "approved"
                    ? "Your review has been approved."
                    : review.status === "rejected"
                        ? "Your review was rejected."
                        : "Your review has already been submitted and is waiting for approval.",
                true
            );

        } catch (error) {

            console.error(
                "PKS: Unable to load student review.",
                error
            );
        }
    }

    async function submitReview() {

        const button =
            getElement(
                "reviewSubmitButton"
            );

        const text =
            getElement(
                "reviewText"
            );

        const rating =
            Number(
                window.pksSelectedRating || 0
            );

        if (!rating) {

            showMessage(
                "Please select a rating between 1 and 5 stars.",
                false
            );

            return;
        }

        const reviewText =
            text
                ? text.value.trim()
                : "";

        if (reviewText.length > 1000) {

            showMessage(
                "Review cannot exceed 1000 characters.",
                false
            );

            return;
        }

        const token =
            getToken();

        if (!token) {

            showMessage(
                "Your student session has expired. Please log in again.",
                false
            );

            return;
        }

        if (button) {

            button.disabled =
                true;

            button.textContent =
                "Submitting...";
        }

        try {

            const response =
                await fetch(
                    API_BASE +
                    "/student/reviews",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json",

                            "Authorization":
                                "Bearer " + token
                        },

                        body:
                            JSON.stringify({
                                rating,
                                reviewText
                            })
                    }
                );

            const data =
                await response.json()
                    .catch(function () {
                        return {};
                    });

            if (!response.ok) {

                throw new Error(
                    data.message ||
                    "Unable to submit your review."
                );
            }

            if (!data.success) {

                throw new Error(
                    data.message ||
                    "Unable to submit your review."
                );
            }

            showMessage(
                data.message ||
                "Thank you! Your review has been submitted for approval.",
                true
            );

            if (text) {
                text.disabled = true;
            }

            if (button) {

                button.disabled =
                    true;

                button.textContent =
                    "Review Submitted";
            }

        } catch (error) {

            console.error(
                "PKS: Review submission error:",
                error
            );

            showMessage(
                error.message ||
                "Unable to submit your review.",
                false
            );

            if (button) {

                button.disabled =
                    false;

                button.textContent =
                    "Submit Review";
            }
        }
    }

    function initializeSubmitButton() {

        const oldButton =
            getElement(
                "reviewSubmitButton"
            );

        if (!oldButton) {
            return;
        }

        /*
         * Replace the existing button.
         * This removes the old broken event listener
         * without affecting the rest of student.js.
         */

        const button =
            oldButton.cloneNode(true);

        oldButton.parentNode.replaceChild(
            button,
            oldButton
        );

        button.addEventListener(
            "click",
            function (event) {

                event.preventDefault();

                submitReview();
            }
        );
    }

    function initializeCharacterCounter() {

        const text =
            getElement(
                "reviewText"
            );

        const counter =
            getElement(
                "reviewCharCount"
            );

        if (!text || !counter) {
            return;
        }

        function updateCounter() {

            counter.textContent =
                text.value.length +
                " / 1000";
        }

        text.addEventListener(
            "input",
            updateCounter
        );

        updateCounter();
    }

    function start() {

        window.pksSelectedRating =
            0;

        initializeStars();

        initializeSubmitButton();

        initializeCharacterCounter();

        loadMyReview();
    }

    if (
        document.readyState ===
        "loading"
    ) {

        document.addEventListener(
            "DOMContentLoaded",
            start
        );

    } else {

        start();
    }

})();