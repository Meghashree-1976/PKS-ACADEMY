const adminToken =
    sessionStorage.getItem(
        "pksAdminToken"
    );


if (!adminToken) {

    window.location.href =
        "/admin/login.html";
}


/* =========================
   ELEMENTS
========================= */

const attendanceDate =
    document.getElementById(
        "attendanceDate"
    );

const attendanceSearch =
    document.getElementById(
        "attendanceSearch"
    );

const attendanceStatusFilter =
    document.getElementById(
        "attendanceStatusFilter"
    );

const attendanceTableBody =
    document.getElementById(
        "attendanceTableBody"
    );

const emptyAttendance =
    document.getElementById(
        "emptyAttendance"
    );

const attendanceMessage =
    document.getElementById(
        "attendanceMessage"
    );

const presentCount =
    document.getElementById(
        "presentCount"
    );

const lateCount =
    document.getElementById(
        "lateCount"
    );

const totalAttendance =
    document.getElementById(
        "totalAttendance"
    );

const refreshAttendance =
    document.getElementById(
        "refreshAttendance"
    );

const todayButton =
    document.getElementById(
        "todayButton"
    );

const logoutButton =
    document.getElementById(
        "logoutButton"
    );

const recordDateLabel =
    document.getElementById(
        "recordDateLabel"
    );


/* LOCATION ELEMENTS */

const useCurrentLocation =
    document.getElementById(
        "useCurrentLocation"
    );

const saveLocation =
    document.getElementById(
        "saveLocation"
    );

const radiusMeters =
    document.getElementById(
        "radiusMeters"
    );

const academyLatitude =
    document.getElementById(
        "academyLatitude"
    );

const academyLongitude =
    document.getElementById(
        "academyLongitude"
    );

const academyRadius =
    document.getElementById(
        "academyRadius"
    );

const locationStatus =
    document.getElementById(
        "locationStatus"
    );

const locationStatusText =
    document.getElementById(
        "locationStatusText"
    );


/* =========================
   STATE
========================= */

let allAttendance = [];

let selectedLatitude = null;

let selectedLongitude = null;

let savedLocation = null;


/* =========================
   TODAY
========================= */

function getToday() {

    const now =
        new Date();

    const year =
        now.getFullYear();

    const month =
        String(
            now.getMonth() + 1
        ).padStart(
            2,
            "0"
        );

    const day =
        String(
            now.getDate()
        ).padStart(
            2,
            "0"
        );

    return `${year}-${month}-${day}`;
}


/* =========================
   MESSAGE
========================= */

function showMessage(
    message,
    type
) {

    attendanceMessage.textContent =
        message;

    attendanceMessage.className =
        `message show ${type}`;

}


function clearMessage() {

    attendanceMessage.textContent =
        "";

    attendanceMessage.className =
        "message";

}


/* =========================
   HTML SAFETY
========================= */

function escapeHtml(value) {

    return String(
        value ?? ""
    )
        .replaceAll(
            "&",
            "&amp;"
        )
        .replaceAll(
            "<",
            "&lt;"
        )
        .replaceAll(
            ">",
            "&gt;"
        )
        .replaceAll(
            '"',
            "&quot;"
        )
        .replaceAll(
            "'",
            "&#039;"
        );

}


/* =========================
   DATE LABEL
========================= */

function updateDateLabel() {

    const date =
        attendanceDate.value;

    if (!date) {

        recordDateLabel.textContent =
            "";

        return;
    }


    const parsed =
        new Date(
            `${date}T00:00:00`
        );


    if (
        Number.isNaN(
            parsed.getTime()
        )
    ) {

        recordDateLabel.textContent =
            date;

        return;
    }


    recordDateLabel.textContent =
        parsed.toLocaleDateString(
            "en-IN",
            {
                weekday: "long",
                day: "numeric",
                month: "long",
                year: "numeric"
            }
        );

}


/* =========================
   TIME
========================= */

function formatTime(value) {

    if (!value) {
        return "-";
    }


    const date =
        new Date(value);


    if (
        Number.isNaN(
            date.getTime()
        )
    ) {

        return "-";
    }


    return date.toLocaleTimeString(
        "en-IN",
        {
            hour: "2-digit",
            minute: "2-digit"
        }
    );

}


/* =========================
   DISTANCE
========================= */

function formatDistance(
    distance
) {

    if (
        distance === undefined ||
        distance === null
    ) {

        return "-";
    }


    const number =
        Number(distance);


    if (
        Number.isNaN(number)
    ) {

        return "-";
    }


    if (
        number < 1000
    ) {

        return `${Math.round(number)} m`;
    }


    return `${(
        number / 1000
    ).toFixed(2)} km`;

}


/* =========================
   LOAD ACADEMY LOCATION
========================= */

async function loadAcademyLocation() {

    try {

        const response =
            await fetch(
                "/api/admin/academy-location",
                {
                    method: "GET",

                    headers: {
                        Authorization:
                            `Bearer ${adminToken}`
                    }
                }
            );


        if (
            response.status ===
            401
        ) {

            logout();

            return;
        }


        const data =
            await response.json();


        if (
            !response.ok
        ) {

            throw new Error(
                data.message ||
                "Unable to load academy location."
            );

        }


        const location =
            data.location ||
            data.academyLocation ||
            data;


        if (
            location &&
            location.latitude !== undefined &&
            location.longitude !== undefined
        ) {

            savedLocation =
                location;


            academyLatitude.textContent =
                Number(
                    location.latitude
                ).toFixed(6);


            academyLongitude.textContent =
                Number(
                    location.longitude
                ).toFixed(6);


            const radius =
                Number(
                    location.radiusMeters ??
                    location.radius ??
                    100
                );


            academyRadius.textContent =
                `${radius} meters`;


            radiusMeters.value =
                radius;


            locationStatus.classList.add(
                "active"
            );


            locationStatusText.textContent =
                "Configured";

        } else {

            savedLocation =
                null;


            academyLatitude.textContent =
                "Not configured";


            academyLongitude.textContent =
                "Not configured";


            academyRadius.textContent =
                `${radiusMeters.value} meters`;


            locationStatus.classList.remove(
                "active"
            );


            locationStatusText.textContent =
                "Not configured";

        }


    } catch (error) {

        console.error(
            "Academy location error:",
            error
        );

        locationStatus.classList.remove(
            "active"
        );

        locationStatusText.textContent =
            "Not configured";

    }

}


/* =========================
   GET CURRENT LOCATION
========================= */

function getCurrentLocation() {

    clearMessage();


    if (
        !navigator.geolocation
    ) {

        showMessage(
            "Geolocation is not supported by this browser.",
            "error"
        );

        return;
    }


    useCurrentLocation.disabled =
        true;


    useCurrentLocation.textContent =
        "📍 Getting your location...";


    navigator.geolocation.getCurrentPosition(

        function(position) {

            selectedLatitude =
                position.coords.latitude;


            selectedLongitude =
                position.coords.longitude;


            academyLatitude.textContent =
                selectedLatitude.toFixed(6);


            academyLongitude.textContent =
                selectedLongitude.toFixed(6);


            academyRadius.textContent =
                `${radiusMeters.value} meters`;


            saveLocation.disabled =
                false;


            useCurrentLocation.disabled =
                false;


            useCurrentLocation.textContent =
                "📍 Location Captured";


            locationStatus.classList.remove(
                "active"
            );


            locationStatusText.textContent =
                "Ready to save";


            showMessage(
                "Current location captured successfully. Review the radius and click Save Academy Location.",
                "success"
            );

        },


        function(error) {

            useCurrentLocation.disabled =
                false;


            useCurrentLocation.textContent =
                "📍 Use My Current Location";


            let message =
                "Unable to get your location.";


            if (
                error.code ===
                error.PERMISSION_DENIED
            ) {

                message =
                    "Location permission was denied. Please allow location access in your browser and try again.";

            }


            else if (
                error.code ===
                error.POSITION_UNAVAILABLE
            ) {

                message =
                    "Your current location is unavailable. Please check GPS/location services and try again.";

            }


            else if (
                error.code ===
                error.TIMEOUT
            ) {

                message =
                    "Location request timed out. Please try again.";

            }


            showMessage(
                message,
                "error"
            );

        },


        {
            enableHighAccuracy: true,

            timeout: 15000,

            maximumAge: 0
        }

    );

}


/* =========================
   SAVE ACADEMY LOCATION
========================= */

async function saveAcademyLocation() {

    clearMessage();


    if (
        selectedLatitude === null ||
        selectedLongitude === null
    ) {

        showMessage(
            "Please click Use My Current Location first.",
            "error"
        );

        return;
    }


    let radius =
        Number(
            radiusMeters.value
        );


    if (
        !Number.isFinite(radius)
    ) {

        radius = 100;
    }


    if (
        radius < 20
    ) {

        radius = 20;

        radiusMeters.value =
            20;

    }


    if (
        radius > 1000
    ) {

        radius = 1000;

        radiusMeters.value =
            1000;

    }


    saveLocation.disabled =
        true;


    saveLocation.textContent =
        "Saving...";


    try {

        const response =
            await fetch(
                "/api/admin/academy-location",
                {
                    method: "POST",

                    headers: {

                        "Content-Type":
                            "application/json",

                        Authorization:
                            `Bearer ${adminToken}`
                    },

                    body:
                        JSON.stringify({

                            latitude:
                                selectedLatitude,

                            longitude:
                                selectedLongitude,

                            radiusMeters:
                                radius
                        })
                }
            );


        if (
            response.status ===
            401
        ) {

            logout();

            return;
        }


        const data =
            await response.json();


        if (
            !response.ok
        ) {

            throw new Error(
                data.message ||
                "Unable to save academy location."
            );

        }


        savedLocation =
            data.location ||
            data.academyLocation ||
            data;


        academyLatitude.textContent =
            selectedLatitude.toFixed(6);


        academyLongitude.textContent =
            selectedLongitude.toFixed(6);


        academyRadius.textContent =
            `${radius} meters`;


        locationStatus.classList.add(
            "active"
        );


        locationStatusText.textContent =
            "Configured";


        saveLocation.disabled =
            true;


        saveLocation.textContent =
            "✓ Location Saved";


        showMessage(
            "Academy attendance location saved successfully.",
            "success"
        );


        setTimeout(
            function() {

                saveLocation.textContent =
                    "Save Academy Location";

            },
            2500
        );


    } catch (error) {

        console.error(
            "Save location error:",
            error
        );


        saveLocation.disabled =
            false;


        saveLocation.textContent =
            "Save Academy Location";


        showMessage(
            error.message ||
            "Unable to save academy location.",
            "error"
        );

    }

}


/* =========================
   RADIUS CHANGE
========================= */

radiusMeters.addEventListener(
    "input",
    function() {

        const radius =
            Number(
                radiusMeters.value
            );


        if (
            Number.isFinite(radius)
        ) {

            academyRadius.textContent =
                `${Math.min(
                    1000,
                    Math.max(
                        20,
                        radius
                    )
                )} meters`;

        }


        if (
            selectedLatitude !== null &&
            selectedLongitude !== null
        ) {

            saveLocation.disabled =
                false;

            locationStatus.classList.remove(
                "active"
            );

            locationStatusText.textContent =
                "Ready to save";

        }

    }
);


/* =========================
   LOAD ATTENDANCE
========================= */

async function loadAttendance() {

    clearMessage();


    const date =
        attendanceDate.value ||
        getToday();


    updateDateLabel();


    try {

        const response =
            await fetch(
                `/api/admin/attendance?date=${encodeURIComponent(date)}`,
                {
                    method: "GET",

                    headers: {
                        Authorization:
                            `Bearer ${adminToken}`
                    }
                }
            );


        if (
            response.status ===
            401
        ) {

            logout();

            return;
        }


        const data =
            await response.json();


        if (
            !response.ok
        ) {

            throw new Error(
                data.message ||
                "Unable to load attendance."
            );

        }


        allAttendance =
            data.attendance ||
            [];


        renderAttendance();


    } catch (error) {

        console.error(
            "Attendance error:",
            error
        );


        allAttendance =
            [];


        renderAttendance();


        showMessage(
            error.message ||
            "Unable to load attendance.",
            "error"
        );

    }

}


/* =========================
   RENDER ATTENDANCE
========================= */

function renderAttendance() {

    const search =
        attendanceSearch.value
            .trim()
            .toLowerCase();


    const status =
        attendanceStatusFilter.value;


    const filtered =
        allAttendance.filter(
            record => {

                const student =
                    record.student ||
                    {};


                const name =
                    String(
                        student.name ||
                        student.studentName ||
                        ""
                    ).toLowerCase();


                const code =
                    String(
                        student.studentCode ||
                        ""
                    ).toLowerCase();


                const matchesSearch =
                    !search ||
                    name.includes(search) ||
                    code.includes(search);


                const matchesStatus =
                    !status ||
                    record.status ===
                    status;


                return (
                    matchesSearch &&
                    matchesStatus
                );

            }
        );


    const present =
        allAttendance.filter(
            record =>
                record.status ===
                "present"
        ).length;


    const late =
        allAttendance.filter(
            record =>
                record.status ===
                "late"
        ).length;


    presentCount.textContent =
        present;


    lateCount.textContent =
        late;


    totalAttendance.textContent =
        allAttendance.length;


    attendanceTableBody.innerHTML =
        "";


    if (
        filtered.length ===
        0
    ) {

        emptyAttendance.style.display =
            "block";

        return;
    }


    emptyAttendance.style.display =
        "none";


    filtered.forEach(
        record => {

            const student =
                record.student ||
                {};


            const row =
                document.createElement(
                    "tr"
                );


            const statusClass =
                record.status ||
                "present";


            const safeStatus =
                String(
                    statusClass
                ).toLowerCase();


            const displayStatus =
                safeStatus
                    .charAt(0)
                    .toUpperCase() +
                safeStatus.slice(1);


            row.innerHTML = `

                <td>

                    <span class="student-code">

                        ${escapeHtml(
                            student.studentCode ||
                            "-"
                        )}

                    </span>

                </td>


                <td>

                    ${escapeHtml(
                        student.name ||
                        student.studentName ||
                        "-"
                    )}

                </td>


                <td>

                    ${escapeHtml(
                        record.date ||
                        "-"
                    )}

                </td>


                <td>

                    ${formatTime(
                        record.checkInTime
                    )}

                </td>


                <td>

                    ${formatDistance(
                        record.distanceFromAcademy
                    )}

                </td>


                <td>

                    <span
                        class="
                            attendance-status
                            ${escapeHtml(
                                safeStatus
                            )}
                        "
                    >

                        ${escapeHtml(
                            displayStatus
                        )}

                    </span>

                </td>

            `;


            attendanceTableBody.appendChild(
                row
            );

        }
    );

}


/* =========================
   EVENTS
========================= */

attendanceDate.addEventListener(
    "change",
    function() {

        updateDateLabel();

        loadAttendance();

    }
);


attendanceSearch.addEventListener(
    "input",
    renderAttendance
);


attendanceStatusFilter.addEventListener(
    "change",
    renderAttendance
);


refreshAttendance.addEventListener(
    "click",
    function() {

        loadAcademyLocation();

        loadAttendance();

    }
);


todayButton.addEventListener(
    "click",
    function() {

        attendanceDate.value =
            getToday();

        loadAttendance();

    }
);


useCurrentLocation.addEventListener(
    "click",
    getCurrentLocation
);


saveLocation.addEventListener(
    "click",
    saveAcademyLocation
);


/* =========================
   LOGOUT
========================= */

function logout() {

    sessionStorage.removeItem(
        "pksAdminToken"
    );


    sessionStorage.removeItem(
        "pksAdminSession"
    );


    window.location.href =
        "/admin/login.html";

}


logoutButton.addEventListener(
    "click",
    logout
);


/* =========================
   INITIAL LOAD
========================= */

attendanceDate.value =
    getToday();


updateDateLabel();


loadAcademyLocation();


loadAttendance();