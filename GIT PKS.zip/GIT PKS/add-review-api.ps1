$serverPath = ".\server\server.js"

if (!(Test-Path $serverPath)) {
    Write-Host ""
    Write-Host "ERROR: server.js was not found." -ForegroundColor Red
    Write-Host "Make sure this PowerShell window is opened inside:" -ForegroundColor Yellow
    Write-Host "PKS-Foundation-Website" -ForegroundColor Yellow
    exit
}

$content = Get-Content $serverPath -Raw

# ---------------------------------------------------------
# 1. ADD REVIEW MODEL IMPORT
# ---------------------------------------------------------

if ($content -notmatch 'models/Review') {

    $importPattern = 'const Inquiry = require\("\.\./database/models/Inquiry"\);'

    if ($content -match $importPattern) {

        $content = $content -replace `
            $importPattern, `
            'const Inquiry = require("../database/models/Inquiry");' + "`r`n" +
            'const Review = require("../database/models/Review");'

        Write-Host "OK: Review model import added." -ForegroundColor Green

    } else {

        Write-Host ""
        Write-Host "ERROR: Could not find Inquiry model import." -ForegroundColor Red
        Write-Host "No changes were made." -ForegroundColor Yellow
        exit
    }

} else {

    Write-Host "OK: Review model import already exists." -ForegroundColor Green
}


# ---------------------------------------------------------
# 2. REVIEW API
# ---------------------------------------------------------

if ($content -match '"/api/student/reviews"') {

    Write-Host "OK: Review API already exists." -ForegroundColor Green

} else {

$reviewRoutes = @'

/* =========================================================
   REVIEW SYSTEM
========================================================= */


/* =========================================================
   PUBLIC REVIEWS
========================================================= */

app.get(
    "/api/reviews",
    async (req, res) => {

        try {

            const reviews =
                await Review.find({
                    status: "approved",
                    isPublic: true
                })
                .select(
                    "studentName rating reviewText createdAt"
                )
                .sort({
                    createdAt: -1
                });

            const totalRatings =
                reviews.length;

            const averageRating =
                totalRatings > 0
                    ? Number(
                        (
                            reviews.reduce(
                                (
                                    total,
                                    review
                                ) =>
                                    total +
                                    Number(
                                        review.rating
                                    ),
                                0
                            ) /
                            totalRatings
                        ).toFixed(1)
                    )
                    : 0;

            return res.json({

                success: true,

                reviews,

                averageRating,

                totalRatings

            });

        } catch (error) {

            console.error(
                "Public reviews error:",
                error.message
            );

            return res.status(500).json({

                success: false,

                message:
                    "Unable to load reviews."

            });

        }

    }
);


/* =========================================================
   STUDENT - SUBMIT REVIEW
========================================================= */

app.post(
    "/api/student/reviews",

    authenticateStudent,

    async (req, res) => {

        try {

            const rating =
                Number(
                    req.body.rating
                );

            const reviewText =
                typeof req.body.reviewText ===
                "string"

                    ? req.body.reviewText.trim()

                    : "";

            if (
                !Number.isInteger(
                    rating
                ) ||
                rating < 1 ||
                rating > 5
            ) {

                return res.status(400).json({

                    success: false,

                    message:
                        "Please select a rating between 1 and 5."

                });

            }

            if (
                reviewText.length > 1000
            ) {

                return res.status(400).json({

                    success: false,

                    message:
                        "Review is too long. Maximum 1000 characters."

                });

            }

            const student =
                await Student.findById(
                    req.student.studentId
                );

            if (
                !student ||
                !student.isActive
            ) {

                return res.status(401).json({

                    success: false,

                    message:
                        "Student account is inactive or unavailable."

                });

            }

            const existingReview =
                await Review.findOne({

                    student:
                        student._id,

                    status: {
                        $in: [
                            "pending",
                            "approved"
                        ]
                    }

                });

            if (existingReview) {

                return res.status(409).json({

                    success: false,

                    message:
                        "You already have a submitted review."

                });

            }

            const review =
                await Review.create({

                    student:
                        student._id,

                    studentCode:
                        student.studentCode,

                    studentName:
                        student.name,

                    rating,

                    reviewText,

                    status:
                        "pending",

                    isPublic:
                        false

                });

            return res.status(201).json({

                success: true,

                message:
                    "Thank you! Your review has been submitted for approval.",

                review: {

                    id:
                        review._id,

                    rating:
                        review.rating,

                    reviewText:
                        review.reviewText,

                    status:
                        review.status

                }

            });

        } catch (error) {

            console.error(
                "Student review submission error:",
                error.message
            );

            return res.status(500).json({

                success: false,

                message:
                    "Unable to submit your review."

            });

        }

    }
);


/* =========================================================
   STUDENT - MY REVIEW
========================================================= */

app.get(
    "/api/student/reviews/my",

    authenticateStudent,

    async (req, res) => {

        try {

            const review =
                await Review.findOne({

                    student:
                        req.student.studentId

                }).sort({

                    createdAt: -1

                });

            return res.json({

                success: true,

                review:
                    review || null

            });

        } catch (error) {

            console.error(
                "Student review lookup error:",
                error.message
            );

            return res.status(500).json({

                success: false,

                message:
                    "Unable to load your review."

            });

        }

    }
);


/* =========================================================
   ADMIN - GET ALL REVIEWS
========================================================= */

app.get(
    "/api/admin/reviews",

    authenticateAdmin,

    async (req, res) => {

        try {

            const reviews =
                await Review.find()
                    .populate(
                        "student",
                        "studentCode name course"
                    )
                    .populate(
                        "reviewedBy",
                        "name username"
                    )
                    .sort({
                        createdAt: -1
                    });

            const total =
                reviews.length;

            const pending =
                reviews.filter(
                    review =>
                        review.status ===
                        "pending"
                ).length;

            const approved =
                reviews.filter(
                    review =>
                        review.status ===
                        "approved"
                ).length;

            const rejected =
                reviews.filter(
                    review =>
                        review.status ===
                        "rejected"
                ).length;

            const publicReviews =
                reviews.filter(
                    review =>
                        review.status ===
                            "approved" &&
                        review.isPublic ===
                            true
                );

            const averageRating =
                publicReviews.length > 0

                    ? Number(
                        (
                            publicReviews.reduce(
                                (
                                    total,
                                    review
                                ) =>
                                    total +
                                    Number(
                                        review.rating
                                    ),
                                0
                            ) /
                            publicReviews.length
                        ).toFixed(1)
                    )

                    : 0;

            return res.json({

                success: true,

                reviews,

                summary: {

                    total,

                    pending,

                    approved,

                    rejected,

                    publicReviews:
                        publicReviews.length,

                    averageRating

                }

            });

        } catch (error) {

            console.error(
                "Admin reviews error:",
                error.message
            );

            return res.status(500).json({

                success: false,

                message:
                    "Unable to load reviews."

            });

        }

    }
);


/* =========================================================
   ADMIN - APPROVE / REJECT REVIEW
========================================================= */

app.patch(
    "/api/admin/reviews/:id",

    authenticateAdmin,

    async (req, res) => {

        try {

            const status =
                typeof req.body.status ===
                "string"

                    ? req.body.status
                        .trim()
                        .toLowerCase()

                    : "";

            if (
                ![
                    "approved",
                    "rejected"
                ].includes(
                    status
                )
            ) {

                return res.status(400).json({

                    success: false,

                    message:
                        "Status must be approved or rejected."

                });

            }

            const review =
                await Review.findById(
                    req.params.id
                );

            if (!review) {

                return res.status(404).json({

                    success: false,

                    message:
                        "Review not found."

                });

            }

            review.status =
                status;

            review.isPublic =
                status ===
                "approved";

            review.reviewedBy =
                req.admin.adminId;

            review.reviewedAt =
                new Date();

            await review.save();

            return res.json({

                success: true,

                message:
                    status ===
                    "approved"

                        ? "Review approved successfully."

                        : "Review rejected successfully.",

                review

            });

        } catch (error) {

            console.error(
                "Review moderation error:",
                error.message
            );

            return res.status(500).json({

                success: false,

                message:
                    "Unable to update review."

            });

        }

    }
);

'@

    # ---------------------------------------------------------
    # INSERT BEFORE WEBSITE ROUTES
    # ---------------------------------------------------------

    $websiteMarker = '/* =========================================================' + "`r`n" +
                     '   WEBSITE ROUTES'

    if ($content.Contains($websiteMarker)) {

        $content = $content.Replace(
            $websiteMarker,
            $reviewRoutes + "`r`n`r`n" + $websiteMarker
        )

        Write-Host "OK: Review API routes added." -ForegroundColor Green

    } else {

        # Fallback: insert before 404 handlers
        $fallbackMarker = 'app.use((req, res) =>'

        if ($content.Contains($fallbackMarker)) {

            $content = $content.Replace(
                $fallbackMarker,
                $reviewRoutes + "`r`n`r`n" + $fallbackMarker
            )

            Write-Host "OK: Review API routes added before 404 handler." -ForegroundColor Green

        } else {

            Write-Host ""
            Write-Host "ERROR: Could not find a safe insertion point." -ForegroundColor Red
            Write-Host "No server.js changes were saved." -ForegroundColor Yellow
            exit
        }
    }
}


# ---------------------------------------------------------
# 3. BACKUP CURRENT SERVER
# ---------------------------------------------------------

$backupPath = ".\server\server-before-review-backup.js"

Copy-Item `
    $serverPath `
    $backupPath `
    -Force

Write-Host ""
Write-Host "Backup created:" -ForegroundColor Cyan
Write-Host $backupPath -ForegroundColor White


# ---------------------------------------------------------
# 4. SAVE UPDATED SERVER
# ---------------------------------------------------------

Set-Content `
    -Path $serverPath `
    -Value $content `
    -Encoding UTF8

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host " REVIEW SYSTEM CONNECTED SUCCESSFULLY" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green

Write-Host ""
Write-Host "Review endpoints now available:" -ForegroundColor Cyan

Write-Host "GET  /api/reviews"
Write-Host "POST /api/student/reviews"
Write-Host "GET  /api/student/reviews/my"
Write-Host "GET  /api/admin/reviews"
Write-Host "PATCH /api/admin/reviews/:id"

Write-Host ""
Write-Host "Now restart your Node server." -ForegroundColor Yellow