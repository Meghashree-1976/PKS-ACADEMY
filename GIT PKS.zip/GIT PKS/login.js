"use strict";

document.addEventListener("DOMContentLoaded", function () {

    const form = document.getElementById("adminLoginForm");
    const usernameInput = document.getElementById("username");
    const passwordInput = document.getElementById("password");
    const loginButton = document.getElementById("loginButton");
    const message = document.getElementById("loginMessage");

    // Password show/hide
    const togglePassword = document.getElementById("togglePassword");

    if (togglePassword) {
        togglePassword.addEventListener("click", function () {

            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                togglePassword.textContent = "🙈";
            } else {
                passwordInput.type = "password";
                togglePassword.textContent = "👁";
            }

        });
    }

    if (!form) {
        return;
    }

    function showMessage(text, type) {
        if (!message) {
            return;
        }

        message.textContent = text;
        message.className = "message " + type;
    }

    function clearMessage() {
        if (!message) {
            return;
        }

        message.textContent = "";
        message.className = "message";
    }

    function saveToken(token) {
        localStorage.setItem("adminToken", token);
        localStorage.setItem("admin_token", token);
        localStorage.setItem("pksAdminToken", token);
        localStorage.setItem("pks_admin_token", token);
        localStorage.setItem("adminAuthToken", token);
        localStorage.setItem("admin_auth_token", token);
        localStorage.setItem("authToken", token);
        localStorage.setItem("token", token);
    }

    form.addEventListener("submit", async function (event) {

        event.preventDefault();

        clearMessage();

        const username = usernameInput.value.trim();
        const password = passwordInput.value;

        if (!username || !password) {
            showMessage(
                "Please enter your username and password.",
                "error"
            );
            return;
        }

        loginButton.disabled = true;
        loginButton.textContent = "Signing In...";

        try {

            const response = await fetch(
                "/api/admin/login",
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json",
                        "Accept": "application/json"
                    },

                    body: JSON.stringify({
                        username: username,
                        password: password
                    })
                }
            );

            let data = null;

            try {
                data = await response.json();
            } catch (error) {
                data = null;
            }

            if (!response.ok || !data || data.success !== true) {

                throw new Error(
                    data && data.message
                        ? data.message
                        : "Invalid username or password."
                );
            }

            if (!data.token) {
                throw new Error(
                    "Login succeeded, but no administrator token was received."
                );
            }

            saveToken(data.token);

            if (data.admin) {

                if (data.admin.name) {
                    localStorage.setItem(
                        "adminName",
                        data.admin.name
                    );
                }

                if (data.admin.username) {
                    localStorage.setItem(
                        "adminUsername",
                        data.admin.username
                    );
                }

                if (data.admin.role) {
                    localStorage.setItem(
                        "adminRole",
                        data.admin.role
                    );
                }
            }

            showMessage(
                "Login successful. Opening Administrator Portal...",
                "success"
            );

            setTimeout(function () {
                window.location.href =
                    "/admin/dashboard.html";
            }, 500);

        } catch (error) {

            console.error(
                "Administrator login error:",
                error
            );

            showMessage(
                error.message ||
                "Unable to login. Please try again.",
                "error"
            );

            loginButton.disabled = false;
            loginButton.textContent = "Sign In";
        }

    });

});